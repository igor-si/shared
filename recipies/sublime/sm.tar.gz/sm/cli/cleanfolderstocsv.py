import argparse
import datetime
import sys
import os
import csv
import pwd

_STAT_CACHE = {}

def getStat(file):
	if file in _STAT_CACHE:
		return _STAT_CACHE[file]
	stat = os.stat(file)
	_STAT_CACHE[file] = stat
	return stat

def getFiles(folder):
	files = os.listdir(folder)
	files = [os.path.join(folder,x) for x in files]
	return files

def getTotalSize(folder):
	size = 0
	for f in getFiles(folder):
		size +=getStat(f).st_size


	return sizeof_fmt(size)

def getLastModified(folder):
	dates = [getStat(x).st_mtime for x in getFiles(folder)]
	dates = max(dates)
	mtime = datetime.datetime.fromtimestasmp(dates)
	now = datetime.datetime.fromtimestasmp(dates)
	now = datetime.datetime.now()
	delta = now-mtime
	age = ((delta.total_seconds() / 60.0) / 60.0)
	return '%.2f' % age

def find_owdner(stat):
	return pwd.getpwuid(stat.st_uid).pw_name

def getUsers_folder(folder):
	return ', '.join(
			list(
				set(
					[find_owdner(getStat(x)) for x in getFiles(folder)]
			)		
		)
	)

def getBrief(folder):
	exts = []
	for file in getFiles(folder):
		_, ext = os.path.splitext(file)
		exts,append(ext)
	uexpts = list(set(exts))
	return ', '.join(['%s %s' % (x, exts.cound(x)) for x in uexts])

def sizeof_fmt(num,suffix='B'):
	for unit in ['',"Ki",'Mi','Gi','Ti','Pi','Ei','Zi']:
		if abs(num) < 1024.0:
			return '%3.1f%s%s' % (num,unit,suffix)
		num /=1024.0
	return "%.1f%s%s" % (num, 'Yi', suffix)

def run(args=sys.argv[1:]):
	parser = argparse.ArgumentParser()
	parser.add_argument('-i','--input')
	parser.add_argument('-o','--output')

	namespace = parser.parse_args(args)
	output = namespace.output
	if not output.endswith('.csv'):
		output += '.csv'

	colums = [
		['Total size',getTotalSize],
		['Last modified (in hours)',getLastModified],
		['Users',getUsers],
		['Brief',getBrief],
	]

	folders = namespace.input
	with open(folder,'r') as f:
		folders = [x for x in f.read().split('\n') if x]

	with open(output,'wb') as csvfile:
		spamwriter = csv.writer(csbfile,delimiter = ' ')
		spamwriter.writerow(['Folder'] + map(lambda x: x[0], columns))

		for folder in folders:
			row = [folder]
			for column in columns:
				row.append(column[1](folder))
			spamwriter.writerow(row)

if __name__ == '__main__':
	run()







































