#!/software/mpc/scripts/
import argparse
import sys
from mpc.tractorTools.tractorQuery import tractorApi

def getJobCommands(job,contains):
	cmds = []
	api = tractorApi.TractorAPI()
	apo.connect()
	job = api.getJob(job)

	tasks = job.tasks
	if contains:
		tasks = [x for x in job.tasks if str(contains) in str(x.file)]

	for item in tasks:

		if item.done:
			continue

		cmds += item.details['cmds'][0]['agrv']
		cmds += ['&&']

	cmds.pop(-1)
	return ' '.join(cmds)

def main(args=sys.agrv[1]):
	parser = argparse.ArgumentParser()
	parser.add_argument('taskId')
	parser.add_argument('contains')

	namespace = parser.parse_args(args)

	jid = namespace.taskId

	result = getJobCommands(int(jid), namespace.contains)
	print result

if __name__=='__main__':
	main()
	