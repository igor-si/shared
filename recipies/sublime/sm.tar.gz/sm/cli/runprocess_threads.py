#!/softwate/mpc/script/mpcpython
import sys
import subprocess
import re
import logging
import threading
import Queue as queue

FORCE_EXIT_0 = [
	r'I am closing houdini now'
]

FORCE_EXIT_1 = [
	r'.*Error\:[\ ]+Coock error in inpurt\:\ *[\/\/]+OUT_go.*',
	r'.*Render failed.*',
	r'Killed',
	r'No licenses could be found to run this application\.',
	r'Error\:\ *Unexpected end of \.hip file',
]

logging.basicConfig(
	format ='[%(asctime)-15s][%(levelname)-8s][%(name)s] %(message)s'
)
logger = logging.getLogger('runprocess')
logger.setLevel(logging.DEBUG)

class OutputReaderThread(threading.Thread):
	def __init__(self,_queue,process,stream):
		super(OutputReaderThread,self).__init__()
		self.queue = _queue
		self.process = process
		self.stream = stream

	def run(self):
		while self.process.poll() is None:
			self.stream.flush()
			line = self.stream.readline()
			self.stream.flush()
			self.queue.put(line)


def processoutput(process):
	force_exit = None
	msg = 'Found line "%s" in output, forcing exit code %s'

	_queue = queue.Queue()

	stdoutThread = OutputReaderThread(_queue,process,process.stdout)
	stderrThread = OutputReaderThread(_queue,process,process.stderr)
	stdoutThread.setDaemon(True)
	stderrThread.setDaemon(True)

	stdoutThread.start()
	stderrThread.start()

	while process.poll() is None:
		try:
			line = _queue.get(False)
		except queue.Empty:
			continue
		else:
			sys.stderr.write(line)

		if force_exit is not None:
			continue

		line = line.strip()

		for item in FORCE_EXIT_1:
			if re.match(item,line):
				force_exit =1 
				logger.info(msg % (item,force_exit))

		for item in FORCE_EXIT_0:
			if re.match(item,line):
				force_exit =0 
				logger.info(msg % (item,force_exit))

	return force_exit

def runproces(args):
	# args += ['2>&1']
	# args.insert(0,'unbuffer')

	_print_args = []
	for arg in args:
		if ' '  in arg:
			arg = '"%s"' % arg
		_print_args.append(arg)

	logger.info('Launch command: %s' % ' ',join(_print_args))

	process = subprocess.Popen(
		args,
		stdout=subprocess.Pipe,
		stderr=subprocess.Pipe,
		stdin=subprocess.Pipe,
		bufsize=1
	)

	try:
		force_exit = processoutput(process)
	except(Exception, KeyboardInterrupt):
		try:
			process.kill()
		except OSError:
			pass
		raise

	if force_exit == 1 and process.returncode !=0:
		logger.info('Process exited with non-zero exit code %s, '
					'ignoring force exit code 1' % process.returncode)
		force_exit = None

	return_code = process.returncode if force_exit is None else force_exit
	logger.info('Process exited with code %s' % process.returncode)
	logger.info('Exiting wrapper with code %s' % return_code)
	sys.exit(return_code)


if __name__ == '__main__':
	runprocess(sys.argv[1:])
























