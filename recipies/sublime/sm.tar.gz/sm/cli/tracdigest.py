#!/softwate/mpc/script/mpcpython
import argparse
import re
from mpc.tractorTools.tractorQuery import tractorApi

def getFrame(job,task):
	api = tractorApi.TractorAPI()
	api.connect()
	job = api.getJob(job)
	task = [x for x in job.tasks if x.id == task]
	if not task:
		return
	task = task[0]
	meta = [x for x in task.details['cmds'][0]['argv']
			if x.endswith('ripplesctipt')]
	if not meta:
		return

	meta = meta[0]

	regex = ".+\{'frame':(\d+)\}.+"
	with file(meta,'r') as f:
		data = str(f.read().replace('\n',' '))
	result = re.findall(regex,data)
	if result:
		result = int(result[0])
		return result

def main(args=sys.argv[1:]):
	parser = argparse.ArgumentParser()
	parser.add_argument('taskId')
	namespace = parser.parse_args(args)
	jid,tid = namespace.taskId.strip(' ').split(':')
	result = getFrame(int(jid),int(tid))
	if result is None:
		print 'Could not get frame'
	else:
		print 'Frame %s' % result

if __name__ == '__main__':
	main()



