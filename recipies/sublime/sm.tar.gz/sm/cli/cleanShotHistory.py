import logging
import os

handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)

formatter = logging.Formatter('[%(levelname)-7s][%(name)s] %(message)s')

logger = logging.getLogger('cleanShotHistory')
logger.handlers = [handler]
logger.setLevel(logging.INFO)

def main():
	path = os.path.expanduser('~/config/shotHistory')

	with file(path,'r') as f:
		items = sorted(set([x for x in f.read().split('\n') if x]))

	history = []
	pop = []
	for i,item in enumerate(items):
		try:
			job,shot,dept = item.split(' ')
		except Exception:
			print '[WARNING] Line "%s" could not be split in 3' % item
			pop.append(i)
			continue

		history.append('job -d %s %s %s' % (dept,job,shot))
	print '\n',join(history)
	[items.pop(x) for x in pop]

	with file(path,'w') as f:
		f.write('\n'.join(items)+'\n')

if __name__ == '__main__':
	main()
