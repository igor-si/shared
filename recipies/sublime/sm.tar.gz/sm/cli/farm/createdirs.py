#!/softwate/mpc/script/mpcpython
import os
import sys
import argparse
import logging

logging.basicConfig(
	format='[%(asctime)-15s][%(levelname)-8s][%(name)s] %(message)s'
)
name = 'cli.farm.%s' % os.path.splitext(os.path.split(__file__)[-1])[0]
logger = logging.getLogger(name)
logger.setLevel(logging.DEBUG)

def createDirs(dirs):
	for folder in dirs:
		if os.path.isdir(folder):
			logger.info('Folder "%s" alreadt existsm skipping.' % folder)
		else:
			logger.info('Creating folder "%s".' % folder)
			os.makedirs(folder)

def main(args):
	parser = argparse.ArgumentParser()
	parser.add_argument('dirs',nargs='*')

	namespace = parser.parse_args(args)
	createDirs(namespace,dirs)

if __name__ == '__main__':
	main(sys.argv[1:])
