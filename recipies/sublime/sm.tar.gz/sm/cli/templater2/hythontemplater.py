import argparse
import traceback
import sys
import logging
import os
import hou

hou

_root = os.path.dirname(__file__)
if _root not in sys.path:
	sys.path.append(_root)

# This is just the logger setup. Not really necessary but a nice thing to have.
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)
# Formatter
formatter = logging.Formatter('[%(levelname)-7s][%(name)-20s] %(message)s')
handler.setFormatter(formatter)
# Logger
logger = logging.getLogger('templater.houdini.%s' % os.getenv('SHOTNAME'))
logger.handlers = [handler]

def run(args = sys.argv[1:]):
	try:
		import autofxprep
	except:
		logger.error('autofxprep is not available')
		raise SystemExit(1)

	parser = argparse.ArgumentParser()
	parser.add_argument('-f','--fxprep',type=str)
	parser.add_argument('-s','--script',type=str,action='append')

	namespace = parser.parse_args(args)

	if namespace.fxprep:
		logger.info('Loading latest "%s" from FXPREP' % namespace.fxprep)
		autofxprep.run(namespace.fxprep)
		logger.info('Successfully loader setup.')
	else:
		logger.info('No FXPREP setup specified, skipping')

	logger.info('%s scripts found' % len(namespace.script))
	for script in namespace.script:
		logger.info('Executing "%s"...' % script)
		try:
			execfile(script, {'namespace':namespace})
		except Exception as e:
			traceback.print_exc()
			logger.error('Failed to execute script file "%s": %s' %
						(script,e) )
			logger.error('Exiting with code 1')
			raise SystemExit(1)

	logger.info('All node now ,exiting')

if __name__ == '__main__':
	run()
























