#!/softwate/mpc/script/mpcpython
import sys
import subprocess
import re

IGNORE = [
	r'WARNING: .+',
	r'MSG_INFO: .+',
	r'ERROR: Failed to impor \'mpc.+',
	r'^ImportError\(\'.+'
]

def processoutput(process):
	while True:
		stdout = process.stdout.readline()
		process.stdout.flush()

		line = stdout.strip()

		found = False
		for item in IGNORE:
			if re.match(item,line):
				found = True

		if not found:
			sys.stdout.write(stdout)

		sys.stdout.flush()
		sys.stderr.flush()

		if stdout == '' and process.poll() is not None:
			break


def getAliases():
	_aliases = {}
	aliases = subprocess.check_output(['tcsh','-c','alias'])
	aliases = aliases.replace('\t', ' ')
	aliases = [x for x in aliases.split('\n') if x]

	for alias in aliases:
		cleanalias = [x for x in alias.split(' ') if x]
		_aliases[cleanaslias.pop(0)] = cleanalias

	return _aliases

def runprocess(args):
	aliases = getAliases()

	if not args:
		print "No command specified. Exiting with code 1."
		raise SystemExit(1)

	finalcmd = []
	for arg in args:
		arg = arg.replace('__ANY__','*')
		if arg in aliases:
			finalcmd += aliases[arg]
		else:
			finalcmd.append(arg)

	print 'Launching supressed command:', finalcmd
	process = subprocess.Popen(
		finalcmd,
		stdout=subprocess.PIPE,
		stderr=subprocess.STDOUT,
		bufsize=1
	)
	try:
		processoutput(process)
	except (Exception,KeyboardInterrupt):
		try:
			process.kill()
			print 'Killed process'
		except OSError:
			pass
		raise

	sys.exit(process.returncode)

if __name__ == '__main__':
	runprocess(sys.argv[1:])



