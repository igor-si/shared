#!/software/mpc/scripts/
import os
import sys
import argparse
import shutil

def rename(folder,search, replace,dry_run):
	os.chdir(folder)

	for item in sorded(os.listdir(folder)):
		new = item.replace(search,replace)
		if new == item:
			continue

		print 'Remaining %s to %s %s' % ( 
			item,
			new,
			('(not really)' if dry_run else '')
			)
		if not dry_run:
			shutil.move(item,new)

if __name__=='__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('folder')
	parser.add_argument('search')
	parser.add_argument('replace')
	parser.add_argument('-d',action='store_true')

	namespace = parser.parse_args(sys.argv[1:])
	rename(namespace.folder,namespace.search,namespace.replace,namespace.d)
