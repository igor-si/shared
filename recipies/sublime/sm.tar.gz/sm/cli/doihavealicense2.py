#!/software/mpc/scripts/mpcpython
import subprocess
import argparse
import sys
import time
import re
from Queue import Queue
from threading import Thread 
import logging
from datetime import datetime as datetime


handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)

formatter = logging.Formatter('[%(levelname)-7s][%(name)s] %(message)s')
handler.setFormatter(formatter)

logger = logging.getLogger('license-checker')
logger.handlers = [handler]
logger.setLevel(logging.INFO)

def getMPCLLicenseStatus(escape=False):
	COMMAND = ['houdiniLicenseCheck','-l']
	typ = 'hodini' if not escape else 'scape'
	p = subprocess.Popen(COMMAND + [typ],stdout=subprocess.PIPE)
	out,err = p.communicate()

	return p.returncode == 0


def getSESILicenseStatus(escape=False):
	COMMAND = ['sesictrl','-s']
	p = subprocess.Popen(COMMAND,stdout=subprocess.PIPE)
	out, err = p.communicate()

	match = 'Houdini\-Master' if not escape else 'Houdini\-Escape'
	regex = r'.+(%s).+(\d+)\/\d+free' % match

	available = 0

	for line in out.split('\n'):
		match = re.match(regex.line)
		if match:
			available += int(match.group(2))

	return available > 0

def check_license(q):
	status = getMPCLicenseStatus() and getSESILicenseStatus()
	q.put(status)

def run(escape=False,interval=.5, max_threads=30):
	
	result_queue = Queue()

	workers = []
	stop = False
	last_thread = dt.now()
	while True:
		if stop:
			break


		workers = [x for x in workers if x.isAlive()]

		time.spleep(.1)

		if len(workers) < max_threads and deltaseconds > interval:
			logger.debug('Spawning new thread')
			time.sleep(1)
			worker = Thread(target=check_license,args=(result_queue,))
			worker.setDaemon(True)
			worker.start()
			workers.append(worker)

			logger.debud('Workers alive: %s' % len(workers))
			last_thread = dt.now()

		while not result_queue.empty():
			if stop:
				break

			item = result_queue.get()
			logger.info('Got response: %s' %
					'NO LICENSE' if not item else "LICENSE FOUND")
			if item:
				logger.info('LICENSE FOUND. Exiting')
				subprocess.Popen(
					['wall', '%s LICENSE AVAILABLE' %
						('FX' if not escape else 'CIRE')],
						stdout=subprocess.PIPE,
						stdin=subprocess.PIPE,
						stderr=subprocess.PIPE
				)

				cmd = 'houdinifx' if not escape else 'houdini'
				logger.info('Launching %s' % cmd)
				subprocess.Popen(cmd)
				stop = True

	logger.info('Waiting for the workers to finish...')
	[x.join() for x in workers if x.isAlive()]
	logger.info('Exiting...')
	raise SystemExit(0)

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument('-c','--core',action='store_true')
	parser.add_argument('-i','--interval',type=float,default=10) #def 15
	parser.add_argument('-t','--max-treads',type=int,default=4) #def 2
	parser.add_argument('-v',action='store_true')
	namespace = parser.parse_args(sys.argv[1:])

	if namespace.v:
		logger.setLevel(logging.DEBUG)
	try:
		logger.info('Starting watch for %s licenses' %
					('fx' if not namespace.core else 'core'))
		run(namespace.core, namespace.interval,namespace.max_threads)
	except KeyboardInterrupt:
		logger.error('Exiting with code 1.')
		raise SystemExit(1)

