#!/softwate/mpc/script/mpcpython
import sys
import os
import argparse
import glob
import pwd
import getpass
import datetime

DEFAULT_FILE_TYPES = ['ifd']

_STAT_CACHE = {}

def find_owner(stat):
	return pwd.getpwuid(stat.st_uid).pw_name

def sizeof_fmt(num,suffix='B'):
	for unit in ['',"Ki",'Mi','Gi','Ti','Pi','Ei','Zi']:
		if abs(num) < 1024.0:
			return '%3.1f%s%s' % (num,unit,suffix)
		num /=1024.0
	return "%.1f%s%s" % (num, 'Yi', suffix)

def gather(folders,extensions,user=None,hours=None):
	data = {}
	global _STAT_CACHE
	now = datetime.datetime.now()	
	for folder in folders:
		for root,dirs,files in os.walk(folder,folowLinks=True):
			for file_ in files:
				filepath = os.path.join(root,file_)

				ext = None
				for _ext in extensions:
					if filepath.endswith(_ext):
						ext = _ext
						break

				if ext is None:
					continue

				stat = None
				if hours or user:
					stat = _STAT_CACHE.get(filepath)
					if not stat:
						stat = os.stat(filepath)
						_STAT_CACHE[filepath] = stat

					if hours:
						mtime = datetime.datetime.fromtimestamp(stat.st_mtime)
						delta = now - mtime
						age = ((delta.total_seconds() / 60.0) / 60.0)
						if age<hours:
							continue

					if user:
						try:
							owner = find_owner(stat)
						except Exception:
							continue
						if owner not in user:
							continue

					data.setdefault(root,{})
					data[root].setdefault(ext,[])
					data[root][ext].append(filepath)
	return data

def expand(patterns):
	folders = []
	for pattern in patterns:
		folder += glob.glob(pattern)

	return folders


def sizeof(files):
	global _STAT_CACHE
	size = 0
	for file_ in files:
		stat = _STAT_CACHE.get(file_)
		if not stat:
			stat = os.stat(file_)
			_STAT_CACHE[file_] = stat
		size += stat.st_size
	return size,sizeof_fmt(size)

def main(args):
	parser = argparse.ArgumentParser()
	parser.add_argument(
		'--pattern','-p',
		action='append',required=True,
		help=(
			'What pattern to look for. Accepts "*" as wildcards. Example:'
			'-p "/jpbs/ahb/*/*/release/work/mantraIdf*"'
		)
	)
	parser.add_argument(
		'--ext','-x',
		action='append',
		help='Extensions to look for. Defaults to "%s"' % DEFAULT_FILE_TYPES
	)
	parser.add_argument(
		'--user','-u',action='append',
		default = [],
		help = ('Limits search to files to a specific iser. Defaults to the'
			' current user. I can be "*"')
	)
	parser.add_argument(
		'-o','--output',
		help='Writes the folders to that file'
	)
	parser.add_argument(
		'--do-delete',action='store_true',
		help='Delete all files.'
	)
	parser.add_argument(
		'-B','--before',
		help='Only files created before this in hours',
		default=(5.0 * 24.0),
		type=float
	)

	namespace = parser.parse_args(args)

	file_types = namespace.ext or DEFAULT_FILE_TYPES
	folders = expand(namespace.pattern)

	user = namespace.user or [getpass.getuser()]
	if '*' in users or '__ANY__' in users:
		users = None

	data = gather(folders, file_types, users, namespace.before)

	if namespace.brief:
		totalsize = 0
		for folder, files in data.items():
			files_format = []
			files_ = []
			for ext, flist in sorted(files.items(), key=lambda x: x[0]):
				files_format.append('%s %s files' % (len(flist),ext))
				files_ += flist

			size,sizemt = sizeof(files_)
			print folder , '\n\t%s (%s)' % (sizefmt,', '.join(files_format))
			# print '\n\tTOTAL: %s' % sizefrmt
			totalsize += size

		print 'GLOBAL', sizeof_fmt(totalsize)

	file_list = []
	for files in data.values():
		for flist in files.values():
			file_list += flist

	folders = list(set([os.path.split(x)[0] for x in file_list]))

	if namespace.output:
		with file(namespace.output, 'w') as f:
			f.write('\n'.join(sorted(list(set(folders)))))

	if namespace.do_delete:
		in_ = raw_input('Are you sure you want to delete %s files (%s)? [y,N]'
						% (len(file_list), sizeof(file_list)))
		response = in_.lower() == 'y'
		if not response:
			print 'Exiting'
		else:
			print 'DIRECT DELETING IS DISABLED. SORRY. TO DANGAROUS'

if __name__ == '__main__':
	main(sys.argv[1:])
















 





















































					





