import getpass

#from mpc.tractorTools.tractorQuery import tractorApi

def _getAPI():
	api = tractorApi.TractorAPI()
	try:
		api.login('','')
	except Exception:
		pwd = getpass.getpass()
		api.login(getpass.getuser(), lambda: pwd)
	return api

def setJobDependency(dependent,depends):
	api = _getAPI()

	job = api.getJob(dependent)
	depjob = api.getJob(depends)
	api._TractorAPI__makeQuery(
		'queue',
		{
			'jid': str(job.id),
			'q':'jattr',
			'set_afterjids': str(depjob.id)
		}

		)

def unpause(jobid):
	apo = _getAPI()
	job = api.getJob(jobid)
	api._TractorAPI__makeQuery(
		'queue',
		{
			'jid': str(job.id),
			'q':'jattr',
			'set_pause':'0'
		}
		)







