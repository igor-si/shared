import os

tracker_path = os.path.expanduser('~/maruja/tracker')