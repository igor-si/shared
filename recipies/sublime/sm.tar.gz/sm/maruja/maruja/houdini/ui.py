import hou
import re

def getHouCss():
	css = hou.ui.qtStyleSheet()
	regex = r'(\.*QWidget[\[\]\w\=\"|:]*)'

	def addScroll(result):
		line = result.groups()[0]
		return '%s, %s, %s' % (
			line,
			line.replace('QWidget','QScrollArea'),
			line.replace('QWidget','QDialog')
		)

	new = []
	for line in css.split('\n'):
		result = re.sub(regex,addScrollmline)
		new.append(result)

	return '\n'.join(new)
	