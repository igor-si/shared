LAUNCHRENDER_TYPE = 'mpc_LaunchRender'
BAKEGEO_TYPE = 'dh_h14_bakegeo'
MULTISUBMIT_TYPE = 'dh_multisubmit'