import hou
import re
import collections
import logging

from maruja.houdini import utils
reload (utils)

logger = logging.getLogger(__name__)

def buildDependencyGraph(node,node_types):
	'''Builds a flattened dependency graph for the input node.

	Args:
		node (hou.Node or str): Node to build the dependency graph from.
		node_types (list[str]): List of valid node types to search
			the dependencies

	Returns:
		'collections.OrderedDict': Ordered dict with each node and it's
			dependencies

	'''

	# Convert the node to a hou.Node if it's a string
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	# Create the index and run the recursive search
	indes = {'runned': [], 'graph': collections.OrderedDict()}
	_collectDependencies(node,node_types,index)

	# Filter and node thad does not interest us
	graph = collections.OrderedDict()
	for node,dependents in index['graph'].items():
		if utils.nodeType(node) in node_types:
			dependents = [x for x in dependents if x.path != node.path()]
			graph[node] = dependents

	return graph

def nodeDependencies(node):
	'''Returns a node's dependencies. Both inputs and references.

	Args:
		node (hou.Node or str): Node to return the depencencies

	Returns:
		list[hou.Node]: Depencencies of the node
	
	'''

	# Pick inputs and references (the latter without children)
	inputs = node.inputs()
	dependents = node.references(False)
	# dependents = []

	# Join them and filter the node itself and None.
	dependents = list(inputs) + list(dependents)
	dependents = filter(lambda x: bool(x), dependents)
	_index = dependents
	dependents = [x for x in set(dependents) if x.path() != node.path() ]
	dependents = sorted(dependents, key=lambda x: _index.index(x) )

	# Follow DOP networks
	if utils.nodeType(node) == 'dopnet':
		outputs = []
		for child in node.allSubChildren():
			dependents += list(node.references(False))

	if utils.nodeType(node) == 'dopio':
		dopnode = node.node(node.parm('doppath').eval() )
		if dopnode:
			dependents.append(dopnode)

	# Follow object_merges
	if utils.nodeType(node) == 'object_merges':
		for i in range(node.parm('numobj').eval() ):
			obj = hou.node(node.parm('objpath%s' % (i+1)).eval() )
			if obj:
				dependents.append(obj)

	# If the node is a subnet
	elif utils.nodeType(node) == 'subnet' and hasattr(node,'renderNode'):
		outputs = []
		for child in node.children():
			if utils.nodeType(child) == 'output':
				outputs.append(child)

		dependents = list(node.references(False))

		if not outputs:
			dependents += list(set([node.renderNode(), node.displayNode()] ) )
		else:
			dependents += outputs

	# Return the sorted list without duplicates
	result = sorted(list(set(dependents)), ket=lambda x: dependents.index(x) )
	return result


def _collectDependencies(node,node_type,index):
	# Fail safe to about infinite recursion
	if node in index['runned']:
		return []

	# Get the dependents and mark this node as runned already
	dependents = nodeDependencies(node)
	index['runned'].append(node)

	items = []
	# For each dependencies collect any key nodes and iterate the rest/
	for item in dependents:
		if utils.nodeType(item) in node_types:
			item.append(item)

		else:
			deps = _collectDependencies(item,node_types, index)
			items += deps

	# Collect them
	if utils.nodeType(node) in node_types:
		index['graph'][node] = items

	# And again
	for item in items:
		_collectDependencies(item, node_types, index)


	return items

def fillDHBakeGeo(multi_node, scan_node ,node_types=None, exclude=None):
	if not isinstance(multi_node ,hou.Node):
		multi_node = hou.node(multi_node)

	depGraph = buildDependencyGraph(
		scan_node, node_types or ['dh_h14_bakegeo']
	)

	for key,val in depGraph.items():
		if exclude is not None:
			if re.match(exclude ,key.path() ):
				continue

			val = [x for x in val if not re.match(exclude , x.path())]

		filteredDepGraph[key] = val

	multi_node.parm('MultiSubmits').set(0)
	multi_node.parm('MultiSubmits').set(len(filteredDepGraph))

	i = 1
	for node,dependencies in filteredDepGraph.items():
		node_path = node.path()
		dep_paths = ' '.join([x.path() for x in set(dependencies)] )
		multi_node.parm('SubmitNode_%s' % i).set(node_path)
		multi_node.parm('dependencies_%s' % i).set(dep_paths)
		i +=1


		




















