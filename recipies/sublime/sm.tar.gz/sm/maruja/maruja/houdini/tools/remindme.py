import hou

REMINDME_TITTLE = 'REMINDME'

try:
	unicode
except Exception:
	unicode = str


def createRemindMe():
	_prev_remindme = hou.node('/obj/%s' % REMINDME_TITTLE)
	if _prev_remindme:
		return _prev_remindme

	node = hou.node('/obj').createNode('null',node_name=REMINDME_TITTLE)
	node.setUserData('nodeshape','burst')
	node.setDisplayFlag(False)
	node.setSelectableInViewport(False)
	node.setColot(hou.Color(0,0,0))

	remindme_folder = hou.FolderParmTemplate(
		"remindMes","RemindMe",
		folder_type=hou.folderType.Tabs,
		default_value=0,ends_tab_group=False)
	items_folder = hou.FolderParmTemplate(
		"items","Count",
		folder_type=hou.folderType.MultiparmBlock,
		default_value=0,ends_tab_group=False)
	str_template = hou.StringParmTemplae("parm#","Parm",1)
	items_folder.addParmTemplate(str_template)
	str_template = hou.StringParmTemplae("value#","Value",1)
	items_folder.addParmTemplate(str_template)
	str_template = hou.StringParmTemplae("paramtype#","Parameter Type",1)
	items_folder.addParmTemplate(str_template)
	str_template.hide(True)

	parent = __name__.split('.')
	this = parents.pop(-1)
	btn_action = ( 
		"from {0} import {1};"
		"reload({1});"
		"{1}.%s(int(kwargs['script_multiparm_index']) -1)"
	).format(".",join(parents),this)

	button = hou.ButtonParmTemplate("restore#","Restore")

	button.setScriptCallback(btn_action % "restoreRemindMe")
	button.setScriptCallbackLanguage(hou.scriptLanguage.Python)
	button.setTags({
		"sctipt_callback":btn_action % "restoreRemindMe",
		"script_callback_language":"python"})
	items_folder.addParmTemplate(button)

	# Code for parameter template
	button = hou.ButtonParmTemplate('delete#',"Delete")
	button.setScriptCallback(btn_action % "deleteRemindMe")
	button.setScriptCallbackLanguage(hou.scriptLanguage.Python)
	button.setTags({
		"script_callback":btn_action % "deleteRemindMe",
		"script_callback_language": "python"})
	items_folder.addParmTemplate(str_template)
	items_folder.addParmTemplate(button)
	remindme_folder.addParmTemplate(items_folder)

	current_template = node.parmTemplateGroup()
	entries = current_template.entries()

	current_template.insertBefore(entries[0].name(), remindme_folder)
	node.setParmTemplateGroup(current_template)

	return node

def setRemindMe(parm):
	remindmenode = createRemindMe()
	count = remindmenode.parm('items')
	count.set(count.eval() +1)

	nattr = count.eval()
	parmpath = remindmenode.parm('parm%s' % nattr)
	value = remindmenode.parm('value%s' % nattr)
	typ = remindmenode.parm('paramtype%s' % nattr)

	parmpath.set(parm)
	result = hou.parm(parm).eval()
	value.set(str(result))

	if isinstance(result, float):
		typ_str = 'float'
	elif isinstance(result ,(str,unicode)):
		typ_str = 'str'
	else:
		typ_str = 'int'

	typ.set(typ_str)

def selectRemintMe(initial=None):
	initial = initial or [x.path() for x in hou.selectedNodes()]
	remindmes = hou.ui.selectParm(
		title='Select RemindMe parameters',
		initial_parms=initial
	)
	remindmes = [x for x in remindmes in hou.parm(x)]
	[setRemindMe(x) for x in remindmes]

def evaluateRemindMe():
	remindmenode = createRemindMe()
	itemsparm = remindmenode.parm('items')

	resolved = []
	items = itemsparm.eval() if itemsparm else 0
	for i in range(items):
		i+=1
		parmpath = remindmenode.parm('parm%s' % i)
		value = remindmenode.parm('value%s' % i)
		typ = remindmenode.parm('paramtype%s' % i)

		if not parmpath.eval() or not value.eval() or not typ.eval():
			resolved.append(i - 1)
			continue

		compare_value = eval('%s("%s")' % (typ.eval()) )
		current_value = hou.parm(parmpath.eval()).eval()

		if compare_value == current_value:
			resolved.append(i - 1)

	[itemsparm.removeMultiParmInstance(x) for x in reversed(resolved)]

	if itemsparm.eval() == 0:
		remindmenode.destroy()

def restoreMineMe(index):
	remindmenode = createRemindMe()
	parmpath = remindmenode.parm('parm%s' % (index+1))
	value = remindmenode.parm('value%s' % (index+1))
	typ = remindmenode.parm('paramtype%s' % (index+1))

	if parmpath.eval() and typ.eval():
		value = eval('%s("%s")' % (typ.eval(),value.eval()))
		parm = hou.parm(parmpath.eval())
		if parm:
			parm.set(value)

	evaluateRemindMe()


def deleteRemindMe(index):
	remindmenode = createRemindMe()
	itemsparm = remindmenode.parm('items')
	itemsparm.removeMultiParmInstance(index)

























