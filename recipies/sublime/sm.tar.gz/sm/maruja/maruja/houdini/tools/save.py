import os
import re
import hou
import logging

logger = logging.getLogger(__name__)

NAME_REGEXES = [
	[r'[\w\d]+?_(.+)_v(\d+)_t(\d+)',lambda x: x.groups()],
	[r'fx_(.+)_v(\d+)_t(\d+)', lambda x: x.groups()],
	[r'fx_(.+)_v(\d+)',lambda x: list(x.groups()) + ['1']]

]

class Scene(object):
	def __init__(self,filepath):
		self._folder,self._filename = os.path.split(filepath)

		name,version,take = None,None,None
		for regex,solver_ in NAME_REGEXES:
			result = re.match(regex, self._filename)
			if result:
				name,version,take = solver_(result)
				break

		if name is None:
			raise ValueError('Could not extract data from filepath "%s"' %
								self._filename)

		self.template=self._filename.replace(name,'%s')
		self.template = self.template.replace('v%s' % version, 'v%03d')
		self.template = self.template.replace('v%s' % take, 't%03d')

		self.name=name 
		self.version = int(version)
		self.take = int(take)

	def __str__(self):
		return '%s.v%03d.t%03d' % (self.name,self.version,self.take)

	def format(self):
		filename = self.template % (self.name, self.version ,self.take)
		return os.path.join(self._folder,filename)

def updateMpcStorage(scn=None):
	if scn is None:
		filename = hou.hipFile.name()
		scn = Scene(filename)

	from mpc.houdini.houdiniAssets.storage import houdiniSceneFile
	houdiniSceneFile._houdiniSceneFileStorage.fileName = scn.name
	houdiniSceneFile._houdiniSceneFileStorage.verions = scn.version
	houdiniSceneFile._houdiniSceneFileStorage.take = scn.take

	logger.info('Updated MPC storage with scene "%s"' % str(scn))

def versionUp(filename=None):
	filename = fileName or hou.expandString('$HIPFILE')
	scn = Scene(filename)
	scn.version +=1
	scn.take =1

	while os.path.isfile(scn.format()):
		scn.verion +=1

	hou.hipFile.save(scn.format())
	updateMpcStorage(scn)
	logger.info('Saved file "%s"' % scn.format())
	return scn.format()

def takeUp(filename=None):
	filename=filename or hou.expandString('$HIPFILE')
	scn = Scene(filename)

	while os.path.isfile(scn.format()):
		scn.take+=1

	hou.hipFile.save(scn.format())
	updateMpcStorage(scn)
	logger.info('Saver file "%s"' % scn.format())
	return scn.format()


















































