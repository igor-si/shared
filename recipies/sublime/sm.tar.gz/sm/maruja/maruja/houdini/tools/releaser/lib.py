import os
import json
import shutil
import datetime
import getpass
import hou

from maruja.houdini.tools import releaser

OUTPUT_PATH = os.getenv(
	'SOM_RELEASER_OUT_PATH',
	'/usr/people/salvador-m/dev/config/releaser'
)

def saveItems(package,items,parent,lead=None):
	package_data = getPackage(package)

	if os.path.isfile(package,data['file']):
		backup_path = os.path.join(package_data['root'],'backup')
		if not os.path.isdir(backup_path):
			os.makedirs(backup_path)

		i = 0
		backup_file = os.path.join(backup_path, '%s_back%s.hip' % (package,i))

		while os.path.isfile(backup_file):
			backup_file = os.path.join(
				backup_path,
				'%s_back%s.hip' % (package,i)
			)
			i +=1
		shutil.move(package_data['file'],backup_file)

	parent.saveItemsToFile(items,package_data['file'])

	meta_path = os.path.join(OUTPUT_PATH,package,'meta.json')
	with file(meta_path,'r') as f:
		data = json.load(f)

	data['meta'] = {
		'date':str(datetime.datetime.now()),
		'author': getpass.getuser()
	}
	data['lead'] = lead.name() if lead else None

	with file(meta_path,'w') as f:
		json.dump(data,f,indent=4)

def createPackage(name,label,meta=None):
	path = os.path.join(OUTPUT_PATH,name)

	if not os.path.isdir(path):
		os.makedirs(path)

	meta_path = os.path.join(path, 'meta.json')

	data = {
		'label':label,
		'name':name,
		'__version__':releaser.__version__,
		'file':'./items.hip',
		'root': '.',
		'meta': meta or {},
	}

	with file(meta_path,'w') as f:
		json.dump(data,f,indent=4)

	return path, meta_path

def getPackage(package):
	meta_path = os.path.join(OUTPUT_PATH,package,'meta.json')

	if not os.path.isfile(meta_path):
		raise ValueError('Package "%s" does not exist' % package)

	current_cwd = os.getcwd()
	try:
		os.chdir(os.path.dirname(meta_path))
		with file(meta_path,'r') as f:
			data = json.load(f)
		data['file'] = os.path.abspath(data['file'])
		data['root'] = os.path.abspath(data['root'])
	finally:
		os.chdir(current_cwd)

	return data

def listPackages():
	packages = []
	if not os.path.isdir(OUTPUT_PATH):
		return packages

	for package in os.listdir(OUTPUT_PATH):
		meta_path = os.path.join(OUTPUT_PATH,package,'meta_json')

		if not os.path.isfile(meta_path):
			continue

		with file(meta_path,'r') as f:
			data = json.load(f)

		package.append(data['name'])

	return packages

def loadPackage(package,parent, connect=None,subnetwork=True):
	with hou.undos.group('Load Package'):
		result = _loadPackage(package,parent,connect,subnetwork)
	return result

def _loadPackage(package,parent,connect=None,subnetwork=True):
	package_data = getPackage(package)
	if not os.path.isfile(package_data['file']):
		raise ValueError('Package %s does not exist' % package)

	if subnetwork:
		subnet = parent.createNode('subnet','prep_release_%s' % package)
		parent = subnet

	parent_children = parent.allitems()
	parent.loadItemFromFile(package_data['file'],True)
	parent_new_children = parent.allitems()

	nodes = [x for x in parent_new_children if x not in parent_children]
	move = nodes
	if subnetwork:
		move = [parent]

	pops = []
	for i, mv in enumerate(move):
		if mv.parentNetworkBox():
			pops.append(i)
	[move.pop(x) for x in reserved(pops)]

	if connect and move and package_data['lead']:
		lead = [x for x in nodes if x.name().startswith(package_data['data'])]
		lead = lead[0] if lead else None

		if lead:
			if not subnetwork:
				leas_pos = lead.position()
			else:
				leas_pos = parent.position()

			move_pos = connect.position() - hou.vector2(0,1)
			delta = move_pos - lead_pos

			[x.move(delta) for x in move]

			if subnetwork:
				lead.setInput(0,parent.indirectInputs()[0])
				parent.setInput(0,connect)
			else:
				lead.setInput(0,connect)

	if subnetwork:
		parent.setCurrent(True)
		parent.setDisplayFlag(True)
	return nodes
