import hou
import re

from maruja.houdini import utils
from maruja.houdini.tools import dhlaunch
import maruja.houdini
reload(utils)
reload(maruja.houdini)

SCRIPT = '''node = hou.pwd()
inputs = node.parent().inputs()
if not inputs:
	raise RuntimeError('%s does not have any inputs' % node.parent().path())

render_obj = inputs[0].node('render)
return render_obj.renderNode().path()'''

def createPackageGeoMirror(name,parent='/obj',static=False):
	node = hou.node(parent).createNode(
		'geo',node_name='IN_' + name + "_CACHE")
	[x.destroy() for x in node.children()]
		
	objmrg = node.createNode('object_merge', 'merge_%s' % name)
	objmrg.parm('objpath1').setExpression(SCRIPT, hou.exprLanguage.Python)

	mpcCache = node.createNode(maruja.houdini.BAKEGEO_TYPE,'cache_%s' % name)
	mpcCache.setInput(0,objmrg)

	null = node.createNode('null','OUT')
	null.setDisplayFlag(True)
	null.setRenderFlag(True)
	nullto = mpcCache

	if static:
		timeshift = node.createNode('timeshift','just_a_frame')
		frame_parm = timeshift.parm('frame')
		frame_parm.deleteAllKeyframes()
		frame_parm.set(int(hou.expandString('$FSTART')))
		timeshift.setInput(0,mpcCache)
		nullto = timeshift

	null.setInput(0,nullto)

	node.layoutChildren()

	return node,mpcCache

def createCharCache(nodes=None):
	nodes = nodes or hou.selectedNodes()

	outnodes = []
	taken = []

	for node in nodes:

		ntype = node.type().name()
		static = ntype in ['DynamicModelHierarchyPkg','ModelPkg']

		res = re.match(r'\w+STR(\w+)Av.+',node.name() )
		name = res.group(1) if res else node.name()
		_name = name

		i = 0
		while name in taken:
			name = _name + str(i)
			i += 1

		taken.append(name)

		merge,mpcCache = createPackageGeoMirror(
			name,
			node.parent().path(),
			static
		)

		nbox = node.parentNetworkBox()
		if nbox:
			nbox.addNode(merge)

		merge.setInput(0,node)
		pos = node.position() - hou.vector2(0,1)
		merge.setPosition(pos)
		node.setDisplayFlag(False)

		ropnode =dhlaunch.createBakegeoProxy(mpcCache)

		outnodes.append(ropnode)


	out = hou.node('/out')
	releaseNode = out.glob('geoseqCacheRelease*')
	releaseNode = releaseNode[0] if releaseNode else None 
	if not releaseNode:
		releaseNode = out.createNode(
			maruja.houdini.LAUNCHRENDER_TYPE,'geoseqCacheRelease')

	[releaseNode.setNextInput(x) for x in outnodes]
	out.layoutChildren(outnodes + [releaseNode])

def createRenderMirror(invisible=False):
	for node in hou.selectedNodes():
		mirror = node.parent().createNode('geo','REND_' + node.name())
		mirror.setInput(0,node)
		mirror.setPotision(node.position() + hou.vector2(0,-1))
		mirror.setDisplayFlag(True)
		node.setDisplayFlag(False)
		mirror.setColor(node.color())

		[x.destroy() for x in mirror.children()]

		objmrg = mirror.createNode('object_merge','RENDER')
		objmrg.parm('objpath1').set(node.renderNode().path())

		if invisible:
			null = mirror.createNode('null','VISUALIZE')
			null.setDisplayFlag(True)

		mirror.layoutChildren()



			