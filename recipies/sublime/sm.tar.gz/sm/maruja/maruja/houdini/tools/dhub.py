import json

import hou
from hutil.Qt import QtWidgets

from maruja.houdini import deferred

def copyRenderPaths(node):
	nodes = renderPathsFromNode(node)

	app=QtWidgets.QApplication.instance()
	clipboard = app.clipboard()
	deferred.executeDeferred(lambda: clipboard.setText(json.dumps(nodes)))

def renderPathsFromNode(node):
	if not instance(node, hou.Node):
		node = hou.node(node)


	nodes = {}
	for ancestor in node.inputAncestors():
		if not ancestor.type().name() == 'ifd':
			continue

		name = ancestor.parm('name').eval()
		mono = ancestor.parm('vm_picture').unexpandedString()
		deep_parm = ancestor.parm('vm_dcmfilename')

		deep= None
		if not ancestor.parm('vm_deepresolver').eval() == 'null':
			deep = deep_parm.unexpandedString().replace('$F4','%04d')

		nodes[name] = {
			'mono': mono.replace('$F4','%04d'),
			'deep':deep,
			'range':(ancestor.parm('f1').eval(),ancestor.parm('f2').eval())

		}
	return nodes
