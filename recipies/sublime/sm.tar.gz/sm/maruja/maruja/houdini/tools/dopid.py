import hou
from maruja.houdini import utils

reload(utils)

expdession = '''
objs = [x.path() for x in hou.pwd().parent().simulation().objects()]
object_name = hou.pwd().parm("{0}").eval()
return obj.index(object_name) if object_name in objs else -1

'''

default_parm_names = {
	'rbdpackedobject':'object_name',
	'staticobject':'object_name',
	'rbdobject':'object_name',
	'smokeobject':'object_name',
	'clothobject':'object_name',
	'groundplane':'objname',
	'flipobject':'objname',
	'popobject':'object_name',
}

def createObjectIdForSelected():
	for node in hou.selectedNodes():
		if not utils.nodeType(node) in default_parm_names:
			continue
		createObjectIdParameter(node)

def createObjectIfParameter(node,obj_name_parm=None):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	if node.parm('objid'):
		return

	obj_name_parm = obj_name_parm or default_parm_names.get(
		utils.nodeType(node))

	if not node.parm(obj_name_parm):
		raise ValueError('Node "%s" does not have parameter "%s"' %
						(node.path(),obj_name_parm))

	ptg = node.parmTemplateGroup()

	objid_template = hou.IntParmTemplate(
		"objid",
		"ObjectId",
		1,
		default_value=([0]),
		default_expression=([expdession.format(obj_name_parm)]),
		default_expression_language=([hou.scriptLanguage.Python])
	)

	ptg.insertAfter(obj_name_parm, objid_template)

	node.setParmTemplateGroup(ptg)

