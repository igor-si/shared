def loadOff(filepath,geometry):
	with file(filepath, 'r') as f:
		data = f.read()

	points = []
	points_ = []
	faces = []

	i=0

	load = 'none'
	for line in data.split('\n'):
		line = line.strip()

		if not line:
			continue

		if line == 'OFF':
			continue

		if load == 'none':
			load = 'points'
			npts,nfaces, _ = map(int,line.split(' '))
			i=0
			continue
		if load == 'points':
			points.append(map(float, line.split(' ')))
			i +=1

			if i>npts:
				load = 'faces'
				i = 0
				continue

		if load == 'faces':
			face_data = map(int,line.split(' ')[1:])
			faces.append(face_data)

	for poin in points:
		pt = geometry.createPoint()
		pt.setPosition(point)
		points_.append(pt)

	geometry.createPolygons(face)



