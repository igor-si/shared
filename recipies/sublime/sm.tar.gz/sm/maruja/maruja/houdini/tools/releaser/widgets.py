import hou
from hutil.Qt import QtWidgets

from maruja.houdini import ui
from maruja.houdini.tools.releaser import lib
reload(lib)

class ReleasePublisher(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(ReleasePublisher,self).__init__(parent=parent)
		self.setWindowTitle('Releaser Releaser')
		self.setWindowIcon(hou.qt.mainWindow().windowIcon())
		self.setStyleSheet(ui.getHouCss())

		self.central_layout = QtWidgets.QVBoxLayout(self)
		self.body_layout = QtWidgets.QFormLayout()

		self.package = QtWidgets.QComboBox()
		self.package_name=QtWidgets.QLineEdit()
		self.package_label = QtWidgets.QLineEdit()
		self.package_name.setDisabled(True)
		self.package_label.setDisabled(True)

		self.lead = QtWidgets.QLineEdit()
		self.lead_fill = QtWidgets.QPushButton('<')
		self.lead_layout = QtWidgets.QHBoxLayout()
		self.lead_layout.addWidget(self.lead)
		self.lead_layout.addWidget(self.lead_fill)
		self.lead_fill.setMaximumWidth(20)

		self.body_layout.addRow('Package',self.package)
		self.body_layout.addRow('Package Name',self.package_name)
		self.body_layout.addRow('Package Label',self.package_label)
		self.body_layout.addRow('Input',self.lead_layout)

		self.submit = QtWidgets.QPushButton('Release')

		self.central_layout.addLayout(self.body_layout)
		self.central_layout.addWidget(self.submit)

		self.populatePackages()

		self.package.currentIndexChanged.connect(self.onPackageChanged)
		self.submit.clicked.connect(self.onSubmit)
		self.lead_fill.clicked.connect(self.onAutoFill)

	def populatePackages(self):
		packages = map(lambda x: lib.getPackage(x), lib.listPackages())
		labels = [x['label'] for x in packages]
		self.package.clear()
		self.package.addItems(labels+['New'])
		self.onPackageChanged()

	def onPackageChanged(self):
		new = self.package.currentText() == 'New'
		self.package_name.setDisabled(not new)
		self.package_label.setDisabled(not new)

	def onAutoFill(self):
		selected = hou.selectedNodes()
		selected = selected[0] if selected else None
		if not selected:
			return

		self.lead.setText(selected.path())

	def onSubmit(self):
		new = self.package.currentText() == 'New'
		if new:
			name = self.package_name.text()
			label = self.package_label.text()
			lib.createPackage(name,label)

		else:
			packages = map(lambda x: lib.getPackage(x), lib.listPackages() )
			package = [x for x in packages
						if self.package.currentText() == x['label']]
			package = package[0]
			name = package['name']
			label=package['label']

		lead = hou.node(self.lead.test())
		items = hou.selectedItems()
		parent = [x.parent() for x in items]

		if len(set(parent)) >1 :
			raise ValueError('Selected itemd don\'t share the same parent')

		parent = parent[0]
		lib.saveItems(name,items,parent,lead)
		self.close()


class ReleaseLoader(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(ReleaseLoader,self).__init__(parent=parent)
		self.sewWindowTitle('Releaser Loader')
		self.setWindowIcon(hou.qt.mainWindow().windowIcon() )
		self.setStyleSheet(ui.getHouCss() )

		self.central_layout = QtWidgets.QFormLayout(self)
		self.body_layout = QtWidgets.QFormLayout()

		self.package = QtWidgets.QComboBox()
		self.subnet = QtWidgets.QCheckBox()
		self.subnet.setChecked(True)

		self.submit = QtWidgets.QPushButton('Load')

		self.body_layout.addRow('Package',self.package)
		self.body_layout.addRow('Create in subnet',self.subnet)

		self.central_layout.addLayout(self.body_layout)
		self.central_layout.addWidget(self.submit)

		self.populatePackages()

		self.submit.clicked.connect(self.onSubmit)

	def populatePackages(self):
		packages = map(lambda x: lib.getPackage(x), lib.listPackages())
		labels = [x['label'] for x in packages]
		self.package.clear()
		self.package.addItems(labels)

	def onSubmit(self):
		packages = map(lambda x: lib.getPackage(x), lib.listPackages())
		package = [x for x in packages
					if self.package.currentText() == x['label'] ]
		package=package[0]
		name = package['name']

		selected = hou.selectedNodes()
		if not selected:
			raise RuntimeError('Nothing selected')
		selected = selected[0]
		parent = selected.parent()
		subnet  = self.subnet.isChecked()

		lib.loadPackage(name,parent,selected,subnet)
		self.close()

def show_releaser(parent=None):
	global releaser
	releaser = ReleasePublisher(parent=parent)
	release.show()

def show_loader(parent=None):
	global releaser
	releaser = ReleaseLoader(parent=parent)
	releaser.show()





























