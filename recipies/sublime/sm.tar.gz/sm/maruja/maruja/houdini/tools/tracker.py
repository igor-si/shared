import hou
import json
import os
import logging

from maruja import config
from maruja.houdini import depencency

logger = logging.getLogger(__name__)

def trackRelease(release_node):
	if not isinstance(release_node,hou.Node):
		release_node = hou.node(release_node)

	renders = [x for x in release_node.inputAncestors()]
	renders = [x for x in renders if x.type().name() in ['mpcMantra','ifd']]

	render_versions = {}

	for node in renders:
		name = node.parm('name').eval()
		mantraname = name

		ins = [x for x in node.outputs()
				if x.type().name() == 'makeRenderRelease']

		if ins:
			name = ins[0].parm('name').eval()

		render_versions[name] = {
			'version':node.parm('versionx').eval(),
			'mantraname':mantraname,
			'caches': {}
		}
		render_nodes = [x for x in hou.node(
			'/obj').glob(node.parm('vobject').eval())]
		render_nodes = [x for x in render_nodes if x.isDisplatFlagSet()]
		render_nodes += [x for x in hou.node(
			'/obj').glob(node.parm('forceobject').eval())]
		render_nodes = list(set(render_nodes))

		cache_nodes = set()
		for node in render_nodes:
			assets = depencency.buildDependencyGraph(
				node.renderNode(), ['dh_h14_bakegeo','fileAsset'])
			for value in assets.values()		:

				[cache_nodes.add(x) for x in value]

		cache_dict = {}
		for node in cache_nodes:
			if node.type().name() == 'fileAsset':
				if node.parm('method').eval() !=2:
					msg = 'No support for fileAsset with assetVersion: %s'
					logger.warn(msg % node.path())
					continue

				rop = hou.node(node.parm('ropPath').eval())
				if not rop:
					continue

				version = rop.parm('version1').eval()
				cname = rop.parm('name').eval()
				cache_dict[cname] = version
			else:
				cname=node.parm('element').eval()
				version = node.parm(version).eval()

				cache_dict[cname] = version

		render_versions[name]['caches'] = cache_dict

	target = _trackerConfigPath()
	data = {
		'scene':hou.expandString('$HIPFILE'),
		'versions':render_versions
	}
	with file(target,'r') as f:
		sdata = json.load(f)

	with file(target,'w') as f:
		json.dump(sdata,f,indent=4)

def _trackerConfigPath():
	target = os.path.join(
		config.tracker_path,
		os.getenv('JOB'),
		os.getenv('SCENE'),
		os.getenv('SHOTNAME')
	)

	if not os.path.isdir(target):
		os.makedirs(target)

	target = os.path.join(target,'houdinitracker.json')
	if not os.path.isfile(target):
		with file(target,'w') as f:
			f.write('[]')
	return target




