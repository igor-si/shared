import hou
import logging
import os

from maruja.houdini import deferred as hdefer

import maruja
from maruja.houdini.tools import tracker
from maruja.houdini import utils

logger = logging.getLogger(__name__)

RELEASE_CODE = '''
'''.format(os.path.dirname(os.path.dirname(maruja.__file__)))

def undo():
	try:
		hou.undos.preformUndo()
	except (Exception, hou.Error):
		logger.debud('Unable to perform undo, deferring it.')
		hdefer.executeDeferred(hou.undos.pefrormUndo)

def releaseSelected(undo=True):
	for node in hou.selectedNodes():
		if utils.nodeType(node) == 'mpcRelease':
			release(node,undo)

def release(release_node,do_undo=True,dry_run=False,deferred=False):

	def doMPCOptimizeRelease():
		return _release(release_node, do_undo, dry_run)

	if deferred:
		hdefer.executeDeferred(doMPCOptimizeRelease)
	else:
		return doMPCOptimizeRelease()


def _release(release_node,do_undo=True,dry_run=False):
	if not isinstance(release_node,hou.Node):
		release_node = hou.node(release_node)

	inputs = release_node.inputs()
	try:
		with hou.undos.group('MPC Release Optimization'):
			for node in inputs:
				_cree_nodes(node)
	except Exception:
		undo()
		raise

	try:
		if not dry_run:
			logger.info('Releasing node "%s"')

			with hou.undos.disabler():
				release_node.parm('release').pressButton()

		else:
			logger.info('Not releasing node "%s", dry_run enabled ' %
						release_node.path())

	except(Exception, hou.Error):
		logger.error('Failed to release node "%s"' % release_node.path())
		raise
	finally:
		if do_undo:
			logger.info('Undoing release optimization for node "%s" ' %
						release_node.path())
			undo()

	hou.hipFile.save()
	tracker.trackRelease(release_node)

def _creep_nodes(node):
	node_type = utils.nodeType(node)
	next_creep = None

	if node_type in ['ifd','mpcMantra']:
		if node.isBypassed():
			next_creep = node.inputs()
			bypassNode(node)

	# makeRenderRelease
	if node_type == 'makeRenderRelease':
		nodeinputs = node.inputs()

		cut = False
		if len(nodeinputs) == 1:
			possiblemantra = nodeinputs[0]
			if utils.nodeType(possiblemantra) in ['ifd','mpcMantra']:
				if possiblemantra.isBypassed():
					cut=True

		if cut:
			next_creep = possiblemantra.inputs()
			bypassNode(node,possiblemantra,inputs() )

	# MakeInstancepkg
	if node_type == "MakeInstancepkg":
		ancenstry = node.inputAncestors()
		pkgs = [x for x in ancenstry if 'pkg' in utils.nodeType(x).lower()]

		if node.isBypassed() or all([x.isBypassed() for x in pkgs]):
			next_creep = node.inputs()
			bypassNode(node)
			for pkg in pkgs:
				bypassNode(pkg)

	if node_type == 'mpcCache':
		if node.isBypassed():
			next_creep = node.inputs()
			bypassNode(node)


	# Any kind of package
	startswithmake = node_type.lower().startswith('make')
	endswithpkg = node_type.lower().endswith('pkg')
	if startswithmake and endswithpkg and node.isBypassed():
		source_asset = node.parent().createNode('sourceAsset')
		source_asset.setPosition(hou.vector2(
			node.position()) - hou.vector2(2,0))

		types = source_asset.findTypeNames()
		types = dict([(x.lower(),x) for x in types ])
		node_type = node_type.lower().replace('make','')
		type_ = types.get(node_type)

		if not type_:
			msg = 'Could not determine type for node %s to source'
			raise RuntimeError(msg % node.path())

		source_asset.parm('type').set(type_)
		source_asset.parm('name').set(node.parm('name').evalAsString())
		source_asset.parm('stream').srt('fx')

		for conn in gatherOutputConnections(node):
			outnode = conn.outputNode()
			idx = conn.inputIndex()
			outnode.setInput(ifx,source_asset)

	next_creep = next_creep if next_creep is not None else node.inputs()
	for input_ in next_creep:
		if input_ is None:
			continue

		_creep_nodes(input_)

def bypassNode(node,inputs=None):
	inputs = inputs if inputs is not None else node.inputs()

	merge = node.parent().createNode('merge','bypass_'+node.name())
	merge.setPosition(hou.vector2(node.position())+ hou.Vector2(2,0))

	for conn in inputs:
		merge.setNextInput(conn)

	for conn in gatherOutputConnections(node):
		outnode = conn.outputNode()
		if not outnode and conn.outputItem():
			item = conn.outputItem()
			output_connections ++ gatherOutputConnections(item)
		else:
			output_connections.append(conn)

	return output_connections

def createReleaseNode(network):
	null = network.createNode('null')

	hou_parm_template_group = hou.ParmTemplateGroup()
	hou_parm_template = hou.ButtonParmTemplate('execute','Render')
	hou_parm_template.hide(True)
	
	hou_parm_template.setJoinWithNext(True)
	hou_parm_template.setTags({'takecontrol':'always'})
	hou_parm_template_group.append(hou_parm_template)
	hou_parm_template = hou.ButtonParmTemplate('renderdialog','Controls...')
	hou_parm_template.hide(True)
	
	hou_parm_template.setTags({'takecontrol':'always'})
	hou_parm_template_group.append(hou_parm_template)
	hou_parm_template = hou.ButtonParmTemplate('renderdialog','Controls...')
	hou_parm_template = hou.ButtonParmTemplate('release','Release')
	hou_parm_template.setJoinWithNext(True)
	hou_parm_template.setScriptCallback(
		"exec hou.pwd().parm('code').unexpandedString() ")
	hou_parm_template.setScriptCallbackLanguage(hou.scriptLanguage.Python)
	hou_parm_template.setTags({
		"sctipt_callback": "exec hou.pwd().parm('code').unexpandedString()",
		"sctipt_callback_language":"python"})
	hou_parm_template_group.append(hou_parm_template)

	hou_parm_template = hou.ToggleParmTemplate(
		"undo","Undo optimization", default_value=True)
	hou_parm_template.setJoinWithNext(True)
	hou_parm_template_group.append(hou_parm_template)

	hou_parm_template = hou.ToggleParmTemplate(
		"debug","Dry Run", default_value=False)
	hou_parm_template_group.append(hou_parm_template)

	hou_parm_template = hou.StringParmTemplate(
		"code",
		"code",
		1,
		default_value([RELEASE_CODE]),
		naming_scheme=hou.parmNamingScheme.Base1,
		string_type=hou.stringParmType.Regulart,
		items_generator_script="",
		items_generator_script_language=hou.scriptLanguage.Python,
		menu_type=hou.menuType.Normal)
	hou_parm_template.hide(True)
	hou_parm_template.setTags({'editor':"1","editorlang":"python"})
	hou_parm_template_group.append(hou_parm_template)

	hou_parm_template = hou.FolderParmTemplate(
		'callbacks',
		"Callbacks",
		folder_type=hou.folderType.MultiparmBloack)
	# Code for parameter template
	hou_parm_template2 = hou.StringParmTemplate(
		"callbacks#",
		"Callback",
		1,
		default_value([""]),
		items_generator_script_language=hou.scriptLanguage.Python,)
	
	hou_parm_template2.setTags({
		"editor":"1",
		"editorlang":"python",
		"editorlines":"5-40"
	})

	hou_parm_template.addParmTemplate(hou_parm_template2)
	hou_parm_template_group.addParmTemplate(hou_parm_template)

	null.setParmTemplateGroup(hou_parm_template_group)
	null.setUserData("nodeshape","ensign")
	null.setColor(hou.Color([.3,.5,0.1]))

	return null

def createReleaseNodeForSelected():
	with hou.undos.group('Create Release Optimize nodes'):
		for node in hou.selectedNodes():
			if not utils.nodeType(node) == 'mpcRelease':
				continue

			null = createReleaseNode(node.parent())
			null.setPosition(node.position() - hou.Vector2(0,1))
			null.setName('optimize_' +node.name() )
			null.setInput(0,node)
			node.setSelected(False)
			null.setSelected(True)




	












