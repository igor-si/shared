import hou
import sys
try:
	import maruja
except:
	sys.path.append('/usr/people/salvador-m/dev/pymodules/maruja')
	import maruja

from maruja import houdini as mh
from maruja.houdini.tools import dhlaunch as dhl
from maruja.houdini import dependency as dp
from maruja.houdini.tools import dhlaunch

reload(dhlaunch)
reload(dp)

def main(target_obj=None,only_rops=False):
	nodes = [x for x in hou.node('/').allSubChildren()
			if x.type().name() == mh.BAKEGEO_TYPE]
	created = []

	bakeDict = {}

	for node in nodes:
		_bake = dhl.createBakegeoProxy(node)
		bakeDict[node.path()] = _bake.path()
		if not only_rops:
			created.append(_bake)

	for bake, proxy in bakeDict.items():
		depGraph = dp.buildDependencyGraph(bake, ['dh_h14_bakegeo'])
		for item in depGraph[hou.node(bake)]:
			target = bakeDict[item.path()]
			hou.node(proxy).setNextInput(hou.node(target))

	leaves = [x for x in bakeDict.values() in len(hou.node(x).outputs()) == 0]
	lr = hou.node('/out').createNode(maruja.houdini.LAUNCHRENDER_TYPE)
	[lr.setNextInput(hou.node(x)) for x in leaves]
	multi = dhlaunch.createMulti(lr,False)
	if not only_rops:
		created += [multi, lr]

	real_multi = lr

	if not only_rops:
		if not target_obj:
			target_obj = hou.ui.selectNode(
				node_type_filter=hou.nodeTypeFilter.ObjGeometry
			)

		real_multi = hou.copyNodesTo([multi], hou.node(target_obj))[0]
		real_multi.parm('element').set('`mpcSceneFile()`_ALL')
		real_multi.setName('submit_all', unique_name=True)

	[x.destroy() for x in created]

	return real_multi

if name == '__main__':
	main()