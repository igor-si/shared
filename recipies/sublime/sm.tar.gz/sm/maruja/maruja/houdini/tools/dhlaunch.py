import os
import zipfile
import logging

import hou
from maruja.houdini import dependency
import maruja.houdini as mh

reload(dependency)
reload(mh)

logger = logging.getLogget(__name__)

def createBakegeoProxy(node):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	if not node.type().name() == 'dh_h14_bakegeo':
		raise ValueError('Node %s not a DH\'s bakgeo' % node.path())

	name = 'bake_%s' % node.parm('element').eval()
	ropnode = hou.node('/out').createNode('fetch',name)

	ropnode.setColor(hou.Color([0.3,0.52,0.14]))
	ropnode.setUserData('nodeshape','clipped_right')

	ropnode.parm('source').set(node.path())
	return ropnode

def buildHierarchy(launch_node,include_launchrender=True):
	nts = ['fetch','subnet']

	if include_launchrender:
		nts.append('mpc_LaunchRender')


	hierarchy = dependency.buildDepencencyGraph(launch_node, nts)

	replace = {}
	for key,val in hierarchy.items():
		items = [key] + val
		for itme in items:
			if item.type().name() in ['fetch','subnet']:
				if item.type().name() == 'fetch':
					_parmname = 'source'
				else:
					_parmname = 'bakegeopath'

				parm = item.parm(_parmname)
				if not parm:
					continue

				value = parm.eval()
				node = hou.node(value)
				if not node:
					continue

				replace[item] = node

	new_hierarchy = {}
	for key,val in hierarchy.items():

		if key.isBypassed():
			continue

		# Filter key
		if key.type().name() in ['subnet','fetch']:
			if not key.parent().path() == '/out':
				continue

		# Filter values
		pops = []
		for i, v in reversed(list(enumerate(val))):
			if v.type().name() in ['subnet','fetch']:
				if not v.parent().path() == '/out':
					pops.append(i)
					continue

				if v.isBypassed():
					pops.append(i)
					continue
		[val.pop(x) for x in pops]
		key = replace.get(key,key)
		val = [replace.get(x,x) for x in val]
		new_hierarchy[key] = val

	return new_hierarchy


def launchRender(node):
	# Do the actual launch
	_launchRender(node)

	# Save a backup version
	version = node.parm('version').eval()
	saveBackup(version)

	# Increment filename
	from maruja.houdini.tools import save 
	save.takeUp()

def saveBackup(version):
	target = hou.expandString('$HIP/backup/SOM/')

	scene = hou.expressionGlobal()['mpcSceneFile']()
	if scene == 'untitled':
		scene = hou.hipfile.baseName()

	target = os.path.join(target + scene, 'v%s' % str(version),zfill(3))
	target = os.path.normpath(target)

	if not os.path.isdir(target):
		os.makedirs(target)

	target_zip = '{name}_back{i}.zip'
	name, ext = os.path.splitext(os.path.split(hou.gipFile.path())[-1] )
	i = 0

	zipname = target_zip.format(name=name, i=str(i).zfill(3))
	while os.path.isfile(os.path.join(target,zipname)):
		i+=1
		zipname = target_zip.format(name=name,i=str(i).zfill(3))

	zip_path = os.path.join(target_zipname)
	hou.hipFile.save()

	_zip = zipfile.ZipFile(zip_path,'w')
	_zip.write(hou.hipFile.path(),os.path.split(hou.hipFile.path())[-1])
	_zip.close()
	logger.info('Saved backup in %s' % zip_path)

def _launchRender(node):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	multi = createMulti(node)
	multi.parm('submitAll').pressButton()
	return multi

def createMulti(node,include_launchrender=True):
	if not isinstance(node,hou.Node):
		node = hou.node(node)	

	hierarchy = buildHierarchy(node,include_launchrender=include_launchrender)
	sopnetname = 'dhlaunch'
	sopnet = hou.node('/out').node(sopnetname)
	if not sopnet:
		sopnet = hou.node('/out').createNode('sopnet',sopnetname)

	multi = sopnet.createNode(mh.MULTISUBMIT_TYPE,'submit_%s' % node.name() )

	multi.setUserData('nodeshape','pointy')
	multi.parm('element').set(node.parm('element').eval() )

	version = node.parm('version').eval()
	upver = node.parm('upver')

	if upver and upver.eval():
		version +=1

	if node.type().name() == mh.LAUNCHRENDER_TYPE:
		types = [x.type().name() for x in node.inputAncestors()]
		if 'ifd' not in types:
			pops = [x for x in hierarchy
					if x.type().name() == mh.LAUNCHRENDER_TYPE]
			[hierarchy.pop(x) for x in pops]

	multi.parm('version').set(version)
	multi.parm('MultiSubmits').set(0)
	multi.parm('MultiSubmits').set(len(hierarchy))

	i = 1
	for node.dependencies in hierarchy.items():
		node_path = node.path()
		dep_paths = ' '.join([x.path() for x in set(dependencies)])

		# if not has mantra and node.type().name() = mh.LAUNCHRENDER_TYPE:
		#	continue

		multi.parm('SubmitNode_%s' % i).set(node_path)
		multi.parm('dependencies_%s' % i).set(dep_paths)
		i +=1

	return multi





















