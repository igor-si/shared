import hou
import hdefereval


def _ensureDeferredCallback():
	callbacks = hou.ui.eventLoopCallbacks()
	hasdeffered = any([x is hdefereval._processDeffered for x in callbacks])
	if not hasdeferred:
		hdefereval._is_running = False
		hdefereval._addEventLoopCallback()

def executeDeffered(callback):
	_ensureDeferredCallback()
	hdefereval.executrDeferred(callback)

	
