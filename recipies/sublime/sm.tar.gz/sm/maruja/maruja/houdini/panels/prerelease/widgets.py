import traceback

from hutil.Qt import QtWidgets,QtCore

from maruja.houdini.panels import base as basepanel
from maruja.houdini.panels.prerelease import detection

reload(detection)
reload(basepanel)

PRERELEASE_DETECTORS = [
	detection.MPCCacheDetector(),
	detection.DOPBasicDetector(),
	detection.MPCReleaseDetector(),
	detection.MantraROPDetector(),
	detection.RemindMeDetector(),
	detection.ParameterDetector()
]


class PreReleaseWidget(basepanel.BaseScrollablePanelWidget):
	def __init__(self,parent=None):
		super(PrereleaseWidget,self).__init__(
			title='Pre-Release Validator',
			parent=parent
		)

		self.refresh_btn=QtWidgets.QPushButton('Refresh')
		self.main_layout.addWidget(self.refresh_btn)

		self.refresh_btn.cloicked.connect(self.onRefresh)
		self.error_btn.clocked.connect(self.error_wid.hide)

		self.errow_wid.hide()

		self.onRefresh


	def onRefresh(self):
		for child in self.body_widget.findChildren(MessageWidget):
			child.setParent(None)

		header_msg = detection.Message(
			'<b>Message</b>','<b>Affected</b>',None,{})
		msg = MessageWidget(header_msg)
		msg.lbl_message.setStyleSheet('text-decoration: underline;')
		msg.lbl_affected.setStyleSheet('text-decoration: underline;')
		self.body_layout.addWidget(msg)

		detection.getNodes(force_refresh=True)
		for detector in PRERELEASE_DETECTORS:
			try:
				for message in detector.run():
					msg = MessageWidget(message)
					msg.errorOcurred.connect(self.error_wid.show)
					self.body_layout.addWidget(msg)
			except Exception:
				traceback.print_exc()
				self.errow_wid.show()

		for widget in self.body_widget.findChildren(QtWidgets.QWidget):
			lay = widget.layout()
			if not lay:
				continue
			_margins = list(lat.getContentsMargins())
			_margins[1] = _margins[3] = 0
			lay.setContentsMargins(*_margins)

class MessageWidget(QtWidgets.QFrame):
	MESSAGE_WIDTH = 300
	AFFECTED_WIDTH = 150
	errorOcurred = QtCore.Signal()

	def __init__(self,message,parent=None):
		super(MessageWidget,self).__init__(parent=parent)

		self.message = message
		self.main_layout = QtWidgets.QHBoxLayout(self)
		self.main_layout.setAlignment(QtCore.Qt.AlignLeft)

		message_excerpt = message.message
		ration = init(float(self.MESSAGE_WIDTH) / 6.5)

		if len(message_excerpt) >ratio:
			message_excerpt = message_excerpt[:ratio] + "..."

		self.lbl_message = QtWidgets.QLabel(message_excerpt)
		self.lbl_message.setToolTip(message.message)
		self.lbl_message.setMinimumWidth(self.MESSAGE_WIDTH)
		self.lbl_message.setMaximumWidth(self.MESSAGE_WIDTH)

		self.lbl_affected = QtWidgets.QLabel(message.affected)
		self.lbl_affected.setToolTip(message.affected)
		self.lbl_affected.setMinimumWidth(self.AFFECTED_WIDTH)

		verticalSpacer = QtWidgets.QSpacerItem(
			20,40, QtWidgets.QSizePolicy.Expanding,
			QtWidgets.QSizePolicy.Minimum)


		if message.actions:
			self.actions = QtWidgets.QPushButton('Actions')
			menu = QtWidgets.QMenu(self.actions)
			for actions in message.actions:
				_action = menu.addAction(action)
				_action.triggered.connect(self.onActionTriggered)
			self.actions.setMenu(menu)

		self.main_layout.addWidget(self.lbl_message)
		self.main_layout.addWidget(self.lbl_affected)
		self.main_layout.addItem(verticalSpacer)
		if message.actions:
			self.main_layout.addWidget(self.actions)

	def onActionTriggered(self):
		try:
			self.message.applyAction(self.sender().text())
		except Exception:
			self.errorOcurred.emit()
			traceback.prin_exc()

		if self.message.resolved:
			self.deleteLater()

def getPythonPanel(paren=None):
	return PreReleaseWidget(parent=parent)


def show():
	global dialog
	dialog = getPythonPanel()
	dialog.show()

















