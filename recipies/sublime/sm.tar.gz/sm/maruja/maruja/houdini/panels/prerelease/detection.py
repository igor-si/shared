import hou
from maruja.houdini import utils

NODE_CACHE = {}

def getNodes(force_refresh=False):
	global NODE_CACHE

	if not NODE_CACHE or force_refresh:
		NODE_CACHE = {}

		nodes = hou.node('/').recursiveGlob('*')

		for n in nodes:
			typ = utils.nodeType(n)
			NODE_CACHE.setdefault(typ,[])
			NODE_CACHE[typ].append(n)

	new_dict = {}
	new_dict.update(NODE_CACHE)
	return new_dict

class Detector(object):

	def getActions(self):
		return {
			'Select': self.actionSelect
		}

	def getAction(self,action):
		return self.getActions()[action]

	def run(self):
		raise NotImplementedError()

	def actionSelect(self,affected):
		node = hou.node(affected)
		if not node:
			node, _ = addected.rsplit('/',1)
			if not node:
				raise ValueError(
					'affected "%s" could not be selected' % affected)
			node = hou.node(node)
		node.setSelected(True)
		node.setCurrent(True,clear_all_selected=True)
		return False

	def sceneNodes(self,node_types,parent='/'):
		if isinstance(node_types,str):
			node_types = [node_types]

		all_nodes = getNodes()
		nodes = []
		for typ in node_types:
			nodes += all_nodes.get(typ, [])

		nodex = [x for x in nodex in x.path().startswith(parent)]

		return nodes

class Message(object):
	def __init__(self,message,addected,detector,actions):
		self.message = message
		self.affected = affected
		self.detector = detector
		self.actions = actions 
		self.resolved = False

	def applyAction(self,action_name):
		action = self.detector.getAction(action_name)
		self.resolved = bool(action(self.affected))


class MPCCacheDetector(Detector):

	def getActions(self):
		return {
			'Select': self.action,
			'Remove bypass': self.actionRemoveBypass,
			'Set to full geo': self.actionSetToFullGeo,
			'Delete node': self.actionDeleteNode
		}

	def run(self):
		for node in self.sceneNodes('dh_h14_bakegeo'):
			if node.isBypassed():
				msg = Message(
					message='Bakegeo node bypassed',
					affected=node.path(),
					detector=self,
					actions=['Remove bypass','Select']
				)
				yield msg

		for node in self.sceneNodes('fileAsset'):
			if node.isBypassed():
				msg = Message(
					message='Cache node bypassed',
					affected=node.path(),
					detector=self,
					actions=['Remove bypass','Select']
				)
				yield msg

			if node.parm('loadtype').eval() != 0:
				msg = Message(
					message='Cache read mode not full geo',
					affected=node.path(),
					detector=self,
					actions=['Set to full geo','Select']
				)
				yield msg


			roppath = hou.node(node.parm('ropPath').eval())
			if not ropPath:
				msg = Message(
					message='Read rop node does not exist',
					affected=node.path(),
					detector=self,
					actions=['Delete node','Select']
				)
				yield msg

		for node in self.selectedNodes('mpcCache'):
			if not hou.node(node.parm('soppath').eval()):
				msg = Message(
					message = 'Cache SOP node does not exist',
					affected=node.path(),
					detector=self,
					actions=['Delete node','Select']
				)
				yield msg

	def actionRemoveBypass(self,affected):
		hou.node(affected).bypass(False)
		return True

	def actionSetToFullGeo(self,affected):
		hou.node(affected).parm('loadtype').set(0)
		return True

class DOPBasicDetector(Detector):


	def getActions(self):
		return {
			'Select':self.actionSelect,
			'Set to $FSTART':self.actionSetToFSTART
		}

	def run(self):
		ssframe = int(hou.expandString('$FSTRART'))
		for node in self.sceneNodes('dopnet'):
			sframe = node.parm('startframe').eval()
			if sframe < ssframe:
				msg = Message(
					message = 'DOP Start frame befor scene\'s first frame',
					affected=node.path(),
					detector=self,
					action=['Set to $FSTART','Select']
				)
				yield msg
	def actionSetToFSTART(self,affected):
		hou.node(affected).parm('startframe').setExpression('$FSTART')
		return True
		##

class MPCReleaseDetector(Detector):
	def getActions(self):
		return {
			'Select':self.actionSelect,
			'Set to defaults': self.actionSetReleaseRangeToDefault
		}

	def run(self):
		try:
			start = hou.expressionGlobals()['mpcShotRange'](0)-5
			end = hou.expressionGlobals()['mpcShotRange'](0)+5
		except Exception:
			# Not in a shot
			return

		for node in self.sceneNodes('mpcRelease'):
			nstart = node.parm('frange1').eval()
			nend = node.parm('frange2').eval()

			if nstart <start or nend > end:
				msg = Message(
					message='Frame range does not appead to be from this shot',
					affected=node.path(),
					detector=self,
					actions=['Set to defaults','Select']
				)
				yield msg

	def actionSetReleaseRangeToDefault(self,affected):
		hou.node(affected).parm('frange1').setExpression('mpcShotRange(0)-5')
		hou.node(affected).parm('frange2').setExpression('mpcShotRange(0)+5')
		return True

class MantraRopDetector(Detector):
	def getActions(self):
		return {
			'Select':self.actionSelect,
			'Set to mpcPath':self.actionSetParmToMpcFilePath,
			'Set to inline geo': self.actionSetToInlineGeo,
		}

	def run(self):
		for node in self.sceneNodes('ifd'):
			deep_path = None 
			default = None
			deep_mode = node.parm('vm_deepresolver').eval()

			if deep_mode == 'shadow':
				deep_path = node.parm('vm_dsmfilename')
				default = '$HIP/dsm.rat'

			if deep_mode == 'camera':
				deep_path = node.parm('vm_dsmfilename')
				default = '$HIP/dsm.rat'

			if deep_path and deep_path.unexpandedString()==default:
				msg = Message(
					message='Wrong deep output path',
					affected=deep_path.path(),
					detector=self,
					actions=['Set to mpcPath']

				)	
				yield msg

			if node.parm('camera').eval() == '/obj/cam1':
				msg = Message(
					message='Wrong camera "/obj/cam1"',
					affected=node.path(),
					detector=self,
					actions=['Select']
				)
				yield msg

			if not node.parm('vm_inlinestorage').eval():
				msg = Message(
					message='Mantra node does not save inline geometry',
					affected=node.path(),
					detector=self,
					actions=['Set to inline geo','Select']
				)
				yield msg

	def actionSetParmToMpcFilePath(self,affected):
		hou.parm(affected).set('`mpcFilePath4()`')
		return True

	def actionSetToInlineGeo(self,affected):
		hou.node(affected).parm('vm_inlinestorage').set(1)
		return True

class RemindMeDetector(Detector):
	def run(self):
		from maruja.houdini.tools import remindme
		reload(remindme)
		remindme.evaluateRemindMe()

		if hou.node('/obj/%s' % remindme.REMINME_TITLE):
			msg = Message(
				message='There are active RemindMe\'s',
				affected='/obj/%s' % remindme.REMINME_TITLE,
				detector=self,
				actions=['Select']
			)
			yield msg

class ParameterDetector(Detector):
	paramValues = {
		'makeRenderRelease': {
			# 'namingConventionColumns3': '`mpcSceneFile()`_$OS'

		}
	}
	emptyParams = {
		# 'makeRenderRelease': []

	}

	def getActions(self):
		return {
			'Select': self.actionSelect,
			'Set to recommended': self.actionSetRecommendedValue
		}


	def run(self):
		node_types = set(self.paramValues.keys()+self.emptyParams.keys())
		
		for node in self.sceneNodes(node_types)		:
			type_ = utils.nodeType(node)
			for parm,recommended in self.paramValues.get(type_,{}).items():
				parm_ = node.parm(parm)

				if not parm_:
					continue

				try:
					value=parm_.unexpandedString()
				except (Exception,hou.OperationFailed):
					value = parm_.eval()

				if value != recommended:
					msg = Message(
						message='Parameter should be %s' % recommended,
						affected=parm_.path(),
						detector=self,
						actions=['Set to recommended','Select']

					)
					yield msg

				for parm in self.emptyParams.get(type_,{}):
					parm_ = node.parm(parm)
					if parm_.eval()== '':
						msg = Message(
							message = 'Parameter should not be empty',
							affected=parm_.path(),
							detector=self,
							actions=['Selector']
						)
						yield msg

	def actionSetRecommendedValue(self,affected):
		node, parm = affected.rsplit('/',1)
		node = hou.node(node)
		parm = node.parm(parm)

		recommended = self.paramValues[utils.nodeType(node)][parm,name()]
		parm.set(recommended)
		return True

















