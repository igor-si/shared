import os
import collections
import re
import xml.etree.ElementTree as ET
from glob import glob

import hou

TOOL_SCHEMA = r'BLTGRP([\w_]+)BLTGRP_.+'

def readShelves(pref_path=None):
	pref_path = pref_path or hou.expandString('$HOUDINI_USER_PREF_DIR/toolbar')
	files = glob(os.path.join(pref_path,'*.shelf'))

	actions = collections.OrderedDict()
	for shellfile in files:
		tree = ET.parse(shellfile)
		root = tree.getroot()
		order = []

		for tool in root:
			if tool.tag == 'toolshelf':
				order = [x.attrib['name'] for x in list(tool)]
				continue

			if not tool.tag == 'tool':
				continue

			name = tool.attrib.get('name')
			result = re.match(TOOL_SCHEMA, name)
			if not result:
				continue

			group = result.group(1).replace("_",' ')
			actions.setdefault(group, [])
			actions[group].append({
				'label': tool.attrib['label'],
				'script': [x for x in list(tool) if x.tag == 'script'][0].text,
				'name': tool.attrib['name']
			})

		for key, val in actions.items():
			val = sorted(val, key=lambda x: order.index(x['name']))
			actions[key] = val

	return actions

