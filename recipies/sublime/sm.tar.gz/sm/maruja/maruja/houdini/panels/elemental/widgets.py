import hou

from maruja.houdini.panels import base as basepanel
from maruja.houdini.panels.elemental import tagger
from hutil.Qt import QtWidgets

reload(basepanel)
reload(tagger)

class ElementalWidget(basepanel.BaseScrillablePanelWidget):
	def __init__(self,parent=None):
		super(ElementalWidget,self).__init__(
			title='Elemental',
			parent=parent
		)

		self.element_layout = QtWidgets.QVBoxLayout()
		self.body_layout.addLayout(self.element_layout)

		verticalSpacer = QtWidgets.QSpacerItem(
			20, 40 , QtWidgets.QSizePolicy.Minimum,
			QtWidgets.QSizePolicy.Expanding)

		self.body_layout.addItem(verticalSpacer)

		self.btn_addElement = QtWidgets.QPushButton('Add Element')
		self.btn_reload = QtWidgets.QPushButton('Refresh')

		self.body_layout.addWidget(self.btn_addElement)
		self.body_layout.addWidget(self.btn_reload)

		self.btn_reload.clicked.connect(self.refreshElements)
		self.btn_addElement.clicked.connect(self.onAddElement)

		self.refreshElements()

	def refreshElements(self):
		for child in self.findChildren(ElementWidget):
			child.setParent(None)
			child.deleteLater()

		element_data = tagger.readElementalData()
		for element in element_data.elements.values():
			new_element = ElementWidget(
				element,parent=self
			)
			self.element_layout.addWidget(new_element)

	def onAddElement(self):
		input_ = hou.ui.readInput('New element name')[1]
		input_ = input_.strip()
		if input_:
			tagger.addElement(input_)
		self.refreshElements()

class ElementWidget(QtWidgets.QtWidget):
	def __init__(self,element,parent=None):
		super(ElementWidget,self).__init__(parent=parent)
		self.element = element

		self.body_layout = QtWidgets.QVBoxLayout(self)

		# TOP
		self.top_lay = QtWidgets.QHBoxLayout()
		self.lbl_element = QtWidgets.QLabel(element.name)
		self.lbl.element.setMinimumWidth(100)

		self.actions_btn = QtWidgets.QPushButton('Actions')

		menu = QtWidgets.QMenu(self.actions_btn)
		add_bundle = menu.addAction('Add Bundle')
		self.remove_bundle_menu = menu.addMenu('Remove bundle...')
		delete = menu.addAction('Delete')
		self.actions_btn.setMenu(menu)

		self.top_lay.addWidget(self.lbl_element)
		self.top_lay.addWidget(self.actions_btn)

		# BOTTOM
		self.bot_layout = QtWidgets.QVBoxLayout()
		self.bot_layout.setSpacing(0)

		# BODY ASSIGNMENTS
		self.body_layout.addLayout(self.top_lay)
		self.body_layout.addLayout(self.bot_layout)

		# SIGNALS
		add_bundle.triggered.connect(self.onAddBundle)
		delete.triggered.connect(self.onDelete)

		# INIT
		self._updateWidget()

	def _updateWidget(self):
		self.element = tagget.readElementalData().getElement(self.element.name)
		if not self.element:
			self.deleteLater()
			return

		self.remove_bundle_menu.clear()

		for child in self.findChildren(BundleWidget):
			child.deleteLater()

		for bundle in self.element.bundle.values():
			remove_action = self.remove_bundle_menu.addAction(
				'%s' % bundle.name)
			remove_action.triggered.connect(self.onRemoveBundle)

			self._addBundleWidget(bundle, bundle.status)

	def _addBundleWidget(self,bundle,status):
		bundle_widget = BundleWidget(bundle,self.element.name,self)
		self.bot_layout.addWidget(bundle_widget)

	def onAddBundle(self):
		input_ = hou.ui.readInput('New bundle name')[1]
		input_ = input_.strip()
		if input_:
			tagger.addBundle(self.element.name, input_)
			self._updateWidget()

	def onRemoveBundle(self):
		bundle = self.sender().text()
		tagger.removeBundle(self.element.name,bundle)
		for child in self.findChildren(QtWidgets.QCheckBox):
			if child.text() == bundle:
				child.deleteLater()

		self._updateWidget()

	def onDelete(self):
		tagger.removeElement(self.element.name)
		self.deleteLater()

	def onUpdateBundleStatus(self,status):
		bundle_name = self.sender().text()
		tagger.setBundleStatus(self.element.name, bundle_name, not status)

class BundleWidget(QtWidgets.QtWidget):
	def __init__(self,bundle,element,parent=None):
		super(BundleWidget,self).__init__(parent=parent)
		self.bundle = bundle
		self.element = element

		self.main_layout = QtWidgets.QHBoxLayout(self)
		self.btn_add = QtWidgets.QPushButton('Add')
		self.btn_rm = QtWidgets.QPushButton('Del')

		self.btn_add.setMaximumHeight(18)
		self.btn_add.setMaximumWidth(55)
		self.btn_rm.setMaximumHeight(18)
		self.btn_rm.setMaximumWidth(55)

		self.check = QtWidgets.QCheckBox(self.bundle.name)
		self.check.setChecked(not self.bundle.status)

		self.main_layout.addWidget(self.btn_rm)
		self.main_layout.addWidget(self.btn_add)
		self.main_layout.addWidget(self.check)

		self.btn_add.clicked.connect(self.onAdd)
		self.btn_rm.clicked.connect(self.onDelete)
		self.check.toggled.connect(self.onToggle)


	def onAdd(self):
		for node in hou.selectedNodes():
			tagger.addElementNode(self.element,self.bundle.name, node.path() )

		self.onToggle(self.check.isChecked())

	def onDelete(self):
		for node in hou.selectedNodes():
			tagger.removeElementNode(
				self.element,self.bundle.name,node.path())

	def onToggle(self,toggle):
		taggerSetBundleStatus(self.element,self.bundle.name, not toggle)

def getPythonPanel(parent=None):
	return ElementalWidget(parent=parent)

def show():
	global dialog
	dialog = getPythonPanel()
	dialog.show()