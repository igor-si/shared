import hou
import json
import collections


class ElementalData(object):
	def __init__(self, elements=None):
		self.elements = collections.OrderedDict()
		[self.addElement(x) for x in elements or[]]


	def addElements(self,element):
		self.elements[element.name] = element

	def getElement(self,element):
		return self.elements.get(element)

	def removeElement(self,element):
		if self.getElement(element):
			self.elements.pop(element)

	def fromData(self,data):
		for key, val in data.items():
			element = Element(key)
			element.bundlesFromData(val)
			self.addElement(element)

	def serialize(self):
		data = collections.OrderedDict()
		for key,val in self.elements.items():
			data[key] = val.serialize()

		return data

class Elements(object):
	def __init__(self,name,bundles=None):
		self.name=name
		self.bundles = collections.OrderedDict()

		[self.addBundle(x) for x in bundles or []]

	def addBundle(self,bundle):
		self.bundles[bundle.name] = bundle

	def removeBundle(self,bundle):
		if bundle in self.bundles:
			self.bundles.pop(bundle)

	def getBundle(self,name):
		return self.bundles.get(name)

	def clearBundles(self):
		self.bundles = collections.OrderedDict()

	def serialize(self):
		data = collections.OrderedDict()

		for name,bundle in self.bundles.items():
			data[name] = bundle.serialize

		return data

	def bundlesFromData(self,data):
		for name,bundledata in data.items():
			new_bundle = ElementBundle(
				name,
				bundledata['status'],
				bundledata['nodes']
			)

			self.addBundle(new_bundle)

class ElementBundle(object):
	def __init__(self,node,status=True, nodes=None):
		self.name=name
		self.status = status
		self.nodes = []
		[self.addNode(x) for x in nodes or []]

	def addNode(self,node,purge=True):
		if not hou.node(node) and purge:
			return

		self.nodes.append(node)
		self.nodes = list(set(self.nodes))

	def removeNode(self,node):
		if node in self.nodes:
			self.nodes.pop(self.nodes.index(node) )

	def serialize(self):
		return {'status':self.status, 'nodes': self.nodes}

def writeElementalData(data):
	elemental_data =json.dumps(data.serialize() )
	cmd = 'set -g ELEMENTALDATA = "%s"' % elemental_data.replace('"','\\"')
	hou.hscript(cmd)

def readElementalData():
	elemental_data = hou.hscript('echo $ELEMENTALDATA')[0].strip or r'{}'
	elemental_data = json.loads(
		elemental_data,
		object_pairs_hook=collections.OrderedDict
	)

	data = ElementalData()
	data.fromData(elemental_data)

	return data

def addElement(element):
	data = readElementalData()
	new_element = Element(name=element)
	data.addElement(new_element)
	writeElementalData(data)

def addBundle(element,bundle):
	data = readElementalData()
	element = data.getElement(element)
	if not element:
		raise ValueError('Element %s does not exist' % element)

	new_bundle = ElementBundle(bundle)
	element.addBundle(new_bundle)

	writeElementalData(data)

def removeElement(element):
	data = readElementalData()
	data.removeElement(element)
	writeElementalData(data)

def getBundle(data,element,bundle):

	element = data.getElement(element)
	if not element:
		raise ValueError('Element %s does not exist' % element)

	bundle = element.getBundle(bundle)
	if not bundle:
		raise ValueError('Bundle %s does not exist' % bundle)

	return bundle

def removeBundle(element,bundle):
	data = readElementalData()
	element = data.getElement(element)
	if not element:
		raise ValueError('Element %s does not exist' % element)

	element.removeBundle(bundle)
	writeElementalData(data)

def setBundleStatus(element,bundle,status):
	data = readElementalData

	bundle = getBundle(data,element,bundle)
	bundle.status = status

	writeElementalData(data)

	for node in bundle.nodes:
		node = hou.node(node)

		if not hasattr(node,'bypass'):

			node.bypass(status)

def addElementNode(element,bundle,node):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	data = readElementalData()

	bundle = getBundle(data,element,bundle)
	bundle.addNode(node.path())

	writeElementalData(data)

def removeElementNode(element,bundle,node):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	data = readElementalData()
	bundle = getBundle(data,element,bundle)
	bundle.removeNode(node.path() )

	writeElementalData(data)
















