import copy
import hou

from hutil.Qt import QtWidgets, QtCore

from maruja.houdini.panels import base as basepanel
from maruja.houdini.panels.toolbelt import parser
from maruja.houdini import menu

reload(parser)
reload(basepanel)

class ToolbeltPanel(basepanel.BaseScrollablePanelWidget):
	def __init__(self,parent=None):
		super(ToolbeltPanel,self).__init__(
			title='Toolbelt',
			parent=parent
		)

		menu_data = menu.loadGroupedMenu()

		for group,items in menu_data['actions'].items():
			btn = QtWidgets.QPushButton(menu_data['groups'][group]['label'])
			menu_ = QtWidgets.QMenu(btn)
			for element in items:
				_action = menu_.addAction(element['label'])
				script = copy.deepcopy(element['script'])
				_action.setProperty('script',script)
				_action.triggered.connect(self.execute)

			btn.setMenu(menu_)
			self.body_layout.addWidget(btn)

	def execute(self):
		code=  self.sender().property('script')
		modifiers = QtWidgets.QApplication.keyboardModifiers()
		keys = {
			'shiftclick':QtCore.Qt.ShiftModifier,
			'alttclick':QtCore.Qt.AltModifier,
			'ctrlclick':QtCore.Qt.ControlModifier
		}

		kwargs = dict([(x,modifiers == y) for x,y in keys.items()])
		try:
			exec(code, {'kwargs': kwargs, 'hou': hou})
		except Exception:
			self.error_wid.show()
			raise

def getPythonPanel(parent=None):
	return ToolbeltPanel(parent=parent)




