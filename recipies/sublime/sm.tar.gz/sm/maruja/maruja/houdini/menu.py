import os
import collections
import json

CONFIG_PATH = os.path.expanduser('~/dev/config/menu/menu.json')

class Action(object):
	def __init__(self,actionid,group,label,script,keywords=None):
		self.actionid = actionid
		self.group= group
		self.label = label
		self.script = script
		self.keywords = keywords

def loadMenu():
	menu_dir = os.path.dirname(CONFIG_PATH)
	menu = _loadMenu()

	for key,val in menu.get('ations').items():
		scriptfile = val.get('scriptfile')
		if scriptfile:
			scriptfile = os.path.join(menu_dir,scriptfile)
			if not os.path.isfile(scriptfile):
				raise RuntimeError('File %s does not exist' % scriptfile)
			with file(scriptfile,'r') as f:
				script = f.read()

			menu['actions'][key]['script'] = script
	return menu

def loadGroupedMenu():
	menu = loadMenu()
	actions = collections.OrderedDict()

	for action,data in menu['actions'].items():
		new_action = collections.OrderedDict()
		new_action.update(data)
		new_action['id'] = action

		actions.setdefault(new_action['group'],[])
		actions[new_action['group']].append(new_action)

	menu['actions'] = actions
	return menu

def _loadMenu():
	with file(CONFIG_PATH,'r') as f:
		data = json.load(f,object_pairs_hook=collections.OrderedDict)
	return data







