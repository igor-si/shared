import hou
from hutil.Qt import QtWidgets, QtCore

from maruja.houdini import ui

def getDuplicatedDefinitions():
	allfiles = hou.hda.loadedFiles()
	hh = hou.expandString('$HH')
	libraries = {}
	for item in allfiles:
		if hh in item or 'houdiniAssets' in item:
			continue

		for _def in hou.hds_definitionsInFile(item):
			type_ = _def.nodeType().name()
			if type_ not in libraries:
				libraries[type_] = []

				libraries[type_].append(_def)
	new = {}
	for key,val in sorted(libraries.items(), key = lambda x: x[0]):
		if len(val)>2:
			new[key] = val
	return new

class CleanHDADialog(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(CleanHDADialog,self).__init__(parent=parent)

		self.current = []
		self.noncurrent = []

		#Window config
		self.setWindowIcon(hou.qt.mainWindow().windowIcon())
		self.setWindowTitle('HDA Cleaner')
		self.resize(1200,900)

		# Central layout
		self.central_layout = QtWidgets.QVBoxLayout(self)

		# Tree
		self.tree = QtQWidgets.QTreeWidget()
		self.tree.setSelectionMode(QtWidgets.QTreeWidget.ExtendenSelection)

		# Buttons
		self.button_layout = QtWidgets.QHBoxLayout()
		self.btn_noncurrent = QtWidgets.QPushButton('Select non-current')
		self.btn_uninstall = QtWidgets.QPushButton('Uninstall selected')

		self.button_layout.addWidget(self.btn_noncurrent)
		self.button_layout.addWidget(self.btn_uninstall)

		# Assignments
		self.central_layout.addWidget(self.tree)
		self.central_layout.addLayout(self.button_layout)

		# Signals
		self.btn_noncurrent.clicked.connect(self.onSelectNonCurrent)
		self.btn_uninstall.clicked.connect(self.onUninstallSelected)

		# Initialization
		self.setStyleSheet(ui.getHouCss())
		self.refresh()


	def refresh(self):
		self.current = []
		self.noncurrent = []

		data = getDuplicatedDefinitions()
		self.tree_root = QtWidgets.QTreeWidgetItem(
			['Name','Is Current','Path'])
		self.tree.clear()
		self.tree.setHeaderItem(self.tree_root)
		self.tree.setColumnWidth(0,250)

		for key, val in sorted(data.items(),key = lambda x: x[0].lower() ):
			root = QtWidgets.QTreeWidgetItem(self.tree,[key,'',''])
			root.setExpanded(True)

			definitions = sorted(val, key=lambda x: int(not x.isCurrent() ) )
			for definition in definitions:
				item = QtWidgets.QTreeWidgetItem(
					root,
					[
						definition.nodeType().name(),
						str(definition.isCurrent()),
						definition.libraryFilePath()
					]
				)
				item.setData(0,QtCore.Qt.UserRole,definition)

				if definition.isCurrent():
					self.current.append(item)
				else:
					self.noncurrent.append(item)


	def onSelectNonCurrent(self):
		for item in self.noncurrent:
			item.setSelected(True)

	def selected(self):
		return self.tree.selectedItems()

	def onUninstallSelected(self):
		libraries = []
		for item in self.selected():
			definition = item.data(0,QtCore.Qt.UserRole)
			if not definition:
				continue

			libraries.append(definition.libraryFilePath())

		[hou.hda.uninstallFile(x) for x in set(libraries)]
		self.refresh()


def show(parent=None):
	global win 
	win = CleanHDADialog(parent=parent)
	win.show()







































