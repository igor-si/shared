import os
import re
import hou
import datetime
import collections
import glob
import getpass
import pwd

from mpc.houdiniAssets import storage
from hutil.Qt import QtWidgets,QtCore

from maruja.houdini import utils
from maruja.houdini import ui
from maruja.houdini import deferred

UNGROUPED = 'Ingrouped'
DEFAULT_REGEXES = [
	[r'[\w\d]+?_(.+)_v(\d+)_t(\d+)\.hip', lambda x: x.groups()],
	[r'fx_(.+)_v(\d+)\.hip', lambda x: list(x.groups()) + ['1']]
]

def find_owner(filename):
	return pwd.getpwuid(os.stat(filename).st_uid).pw_name

class DeferredContextBrowser(object):
	def __init__(self):
		self.context = storage.getContext()
		job = self.context.job

		self.sequences = collections.OrderedDict(
			[(x.name, {'seq': x, 'shots': [] }) for x in job.findScenes()])
		self._loaded_seqs = []

	def __getitem__(selfm,sequence):
		if sequence not in self._loaded_seqs:
			seq = self.sequences[sequence]['seq']
			self.sequences[sequence]['shots'] = seq.findShots()
			self._loaded_seqs.append(sequence)

		return self.sequences[sequence]['shots']

def listHoudiniScenes(
		project=None, scene=None, shot=None, user=None, sort_by_date=False,
		regexes=None):
	scenes = {UNGROUPED: []}
	regexes = regexes or DEFAULT_REGEXES
	path = utils.getHoudiniShotPath(project=project,
									scene=scene,
									shot=shot,
									user=user)
	if not os.path.isdir(path):
		return {}

	scenes_list = os.listdir(path)

	for scene in scenes_list:
		if 'AutoSave' in scene:
			continue

		scene_path = os.path.join(path,scene)

		if not os.path.isfile(scene_path):
			continue

		if not scene_path.endswith("*.hip"):
			continue

		if user is not None and find_owner(scene_path) != user:
			continue

		result = None
		solver = None

		for regex,solver_ in regexes:
			result = re.match(regex,scene)
			if result:
				solver = solver_
				break

		if result and solver:
			name, version , take = solver(result)
			version = int(version)
			take = int(take)
			scene.setdefault(name, [])
			scenes[name].append({
				'version':(version,take),
				'path': scene_path,
				'name': scene,
				'mtime': os.path.getmtime(scene_path)
			})
		else:
			scenes[UNGROUPED].append({
				'version': (1,1),
				'path': scene_path,
				'name': scene,
				'mtime': os.path.getmtime(scene_path)
			})

	sortedDict = collections.OrderedDict()
	sortedDict[UNGROUPED] = scenes[UNGROUPED]
	for key, val in sorted(scenes.items(), key=lambda x: x[0]):

		if key == UNGROUPED:
			continue

		def sortbytake(x):
			return x['version']

		def sortbymodify(x):
			return x['mtime']

		sortedDict[key] = sorted(
			val,key=sortbytake if not sort_by_date else sortbymodify)

	if UNGROUPED in sortedDict:
		sortedDict[UNGROUPED] = sortedDict.pop(UNGROUPED)

	return sortedDict


def formatTime(timesinceepoch):
	date = datetime.datetime.fromtimestamp(timesinceepoch)
	date = date.strftime('%H:%M - %d/%B/%Y')
	return date


class TreeWidgetItem(QtWidgets.QTreeQidgetItem):

	def __lt__(self,otherItem):
		column = self.treeWidget().sortColumn()
		fields = ['version','mtime']
		data1 = self.data(0,QtCore.Qt.UserRole)[fields[column]]
		data2 = otherItem.data(0, QtCore.Qt.UserRole)[fields[column]]
		return data1 < data2


class OpenSceneDialog(QtWidgets.QDialog):
	def __init__(self,regexes=None, ctxpicker=False, parent=None):
		super(OpenSceneDialog,self).__init__(parent=parent)

		# Initial variables
		self.regexes = regexes or DEFAULT_REGEXES
		self.ctxbrowser = DefferedContextBrowser() if ctxpicker else None


		# Window config
		self.setWindowIcon(hou.qt.mainWindow().windowIcon())
		self.setWindowTitle('Open...')
		self.resize(450,500)


		# Central layout
		self.central_layout = QtWidgets.QVBoxLayout(self)

		# Context Picker
		if self.ctxbrowser:
			ctx = storage.getContext()

			curscene = ctx.scene.name
			curshot = ctx.shot.name

			scene = self.ctxbrowser.sequences.keys()
			shot = [x.name for x in self.ctxbrowser[curscene]]

			# Scene combo
			self.scene_combo = QtWidgets.QComboBox()
			self.scene_combo.addItems(scenes)
			self.scene_combo.setCurrentIndex(scenes.index(curscene))

			# Shot combo
			self.shot_combo = QtWidgets.QComboBox()
			self.shot_combo.addItems(shots)
			self.shot_combo.setCurrentIndex(scenes.index(curscene))

			# Picker layout
			self.picker_layout = QtWidgets.QHBoxLayout()
			self.picker_layout.addWidget(self.scene_combo)
			self.picker_layout.addWidget(self.shot_combo)


			# Picker signals
			self.scene_combo.setCurrentIndexChanged.connect(self.onSceneChanged)
			self.shot_combo.currentIndexChanged.connect(self.onContextChanged)

		# Tree widget
		self.tree = QtWidgets.QTreeWidget()
		self.tree.setSortingEnabled(True)
		self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
		self.tree.itemDoubleClicked.connect(self.open)

		# Open button
		self.open_btn = QtWidgets.QPushButton('Open')

		# Central assignments
		if self.ctxbrowser:
			self.central_layout.addLayout(self.picker_layout)

		self.user_layout = QtWidgets.QHBoxLayout()
		self.user_layout.addWidget(QtWidgets.QLabel('User:'))
		self.user_combo = QtWidgets.QComboBox()
		self.user_layout.addWidget(self.user_combo)

		users = self.getUsers()
		self.user_combo.addItems(users)

		self.central_layout.addLayout(self.user_layout)
		self.central_layout.addWidget(self.tree)
		self.central_layout.addWidget(self.open_btn)

		# Signals
		self.open_btn.clicked.connect(self.onOpen)
		self.tree.CustomContextMenuRequested.connect(self.onCustomMenu)
		self.user_combo.currentIndexChanged.connect(self.onUserChanged)


		# Initialozation
		self.setStyleSheet(ui.getHouCss())
		self.populateScenes()
		self.tree.setFocus()


	def onUserChanged(self):
		if self.ctxbrowser:
			scene = self.scene_combo.currentText()
			shot = self.shot_combo.currentText()
		else:
			scene = None
			shot = None
		self.populateScenes(scene=scene,shot=shot)

	def onSceneChanged(self):
		new_scene = self.scene_combo.currentText()
		new_shots = [x.name for x in self.ctxbrowser[new_scene]]
		self.shot_combo.clear()
		self.shot_combo.addItems(new_shots)


	def onContextChanged(self):
		scene = self.scene_combo.currentText()
		shot = self.shot_combo.currentText()

		self.user_combo.clear()
		users = self.getUsers()
		self.user_combo.addItems(users)

		self.populateScenes(scene=scene,shot=shot)

	def populateScenes(self,project=None, scene=None,shot=None):
		user = self.user_combo.currentText()
		scenes = listHoudiniScenes(
			project=project,
			user=user,
			scene=scene,
			shot=shot,
			sort_by_date=True,
			regexes=self.regexes
		)

		self.tree.clear()

		self.tree_root = QtWidgets.QTreeWidgetItem(['Version','Date'])
		self.tree.setHeaderItem(self.tree_root)
		self.tree.setColumnWidth(0,250)

		for key, val in scenes.items():
			if not val:
				continue

			last = sorted(val,key=lambda x: x['mtime'])
			last = formatTime(last[-1]['mtime'])
			root = TreeWidgetItem(self.tree, [key,'Last: %s' % last])
			root.setData(0,QtCore.Qt.UserRole,
						{'version':(1,1),'mtime':1})
		for item in reversed(val):
			v = 'v%s t%s' % (
				str(item['version'][0]).zfill(3),
				str(item['version'][1]).zfill(3)
			)

			if key ==  UNGROUPED:
				v = item['name']

			date = formatTime(item['mtime'])

			titem = TreeWidgetItem(root,[v,item['mtime']])
			titem.setData(1,QtCore.Qt.DisplayRole,date)
			titem.setData(0,QtCore.Qt.UserRole,item)

	def getUsers(self):
		if self.ctxbrowser:
			scene = self.scene_combo.currentText()
			shot = self.shot_combo.currentText()
		else:
			scene = None
			shot = None

		path = utils.getHoudiniShotPath(
			project=None,scene=scene,shot=shot,user='*')
		existing_folders = glob.glob(path)
		users = sorted([os.path.split(x)[-1] for x in existing_folders]	)

		if getpass.getuser() in users:
			users.pop(isers.index(getpass.getuser()))

		users.insert(0,getpass.getuser())

		return users

	def selectedPath(self):
		items = self.tree.selectedItems()
		if not items:
			return

		items = items[0]
		path = items.data(0,QtCore.Qt.UserRole)
		if not path:
			return

		return path.get('path')

	def onOpen(self):
		path = self.selectedPath()

		if not path:
			return

		deferred.executeDeferred(lambda: hou.hipFile.load(path))
		self.close()

	def onCustomMenu(self,position):
		menu = QtWidgets.QMenu(self)
		copyAction = menu.addAction("Copt file path")
		copyAction.triggered.connect(self.onCopyFilePath)
		menu.exec_(self.tree.mapToGlobal(position))


	def onCopyFilePath(self):
		path = self.selectedPath()

		if not path:
			return

		app = QtWidgets.QApplication.instance()
		clipboard = app.clipboard()
		clipboard.setText(path)

def show(parent=None, ctxbrowser=True):
	global wid
	wid = OpenSceneDialog(ctxpicker=ctxpicker,parent=parent)
	wid.show()
	return wid



















































































	
