import logging

from hutil.Qt import QtWidgets,QtCore,QtGui
import hou

from maruja.houdini import menu
from maruja.houdini import deferred

logger = logging.getLogger(__name_)

reload (deferred)

css = '''
QlineEdit {
	border: 2px solid gray;
	border-radius: 10px;
	padding: 0 8px;
}
'''


class ToolSearchWindow(QtWidgets,QMainWindow):
	def __init__(self,parent=None):
		super(ToolSearchWindow,self).__init__(parent=parent)

		parent = hou.qt.mainWindow()
		self.setWindowIcon(hou.qt.mainWindow().windowIcon() )

		self.actions = menu.loadMenu()

		self._labels = {}
		self._submitted = False
		self._closing = False

		self.central_widget = QtWidgets.QWidget(self)
		self.central_layout = QtWidgets.QVBoxLayout(self.central_widget)
		self.setWindowTitle('Seatch bar')
		self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
		self.setCentralWidget(self.central_widget)
		self.setStyleSheet(css)

		point = QtGui.QCursor.pos() + QtCore.QPoint(0,10)
		self.move(point)
		self.resize(200,0)

		self.search = QtWidgets.QlineEdit()
		completer = QtWidgets.QCompleter()
		completer.setCompletionMode(
			QtWidgets.QCompleter.UnfilteredPopupCompletion)
		model = QtCore.QStringListModel()

		completer.setModel(model)
		self.search.setCompleter(completer)
		self.search.setFocus()

		self.central_layout.addWidget(self.search)

		QtWidgets.QApplication.instance().focusChanged.connect(
			self.onFocusChanged
		)
		QtGui.QShortcut(QtGui.QKeySequence("Esc"),self,self.onClose	)
		self.search.editingFinished.connect(self.onSubmit)
		self.search.setFocus()

	def onFocusChanged(self,old,new):
		if new is not self.search:
			self.close()

	def onClose(self):
		self._closing = True
		self.close()

	def fillStringModel(self,model):
		_actions = {}

		for action in self.actions['actions'].values():
			label = action['label']
			_actions.append(label)
			self._labels[label] = action

		model.setStringList(list(sorted(_actions)))

	def onSubmit(self):
		action = self._labels.get(self.search.text())

		if action and not self._submitted and not self._closing:
			self._submitted = True
			deferred.executeDeferred(
				lambda: execCode(action['script'],{'kwags':{}, 'hou': hou })
			)
			logger.info('Executing "%s"' % action['label'])

		self.close()

	def execCode(code,_globals):
		exec(code,_globals)

	def run():
		global menu
		menu = ToolSearchWindow()
		menu.show()























