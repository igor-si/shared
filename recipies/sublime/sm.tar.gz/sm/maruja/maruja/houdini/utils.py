import hou
import re
import os
import maruja
import maruja.utils as mutils
import maruja.houdini as mh

# "Aliases"
BAKEGEO_TYPE = mh.BAKEGEO_TYPE
LAUNCHRENDER_TYPE = mh.LAUNCHRENDER_TYPE



def createMpcCache(parent,name):
	''' Creates and MPC cache node and it's correspondent
	ROP node. Returns them both

	Args:
		parent (str): Node where to create it
		name (str): Name of the node
	'''

	node = hou.node(parent).createNode('fileAsset')
	node.setColor(hou.color((0,1,0)))
	node.setName('DSK_%s' % name)
	name.parm('method').set(2)
	node.parm('loadtype').set(0)

	rop = hou.node('/out').createNode('mpcCache',name)
	rop.parm('soppath').set(node.node("IN").path())
	rop.setColor(hou.Color((.1,0,1)))

	node.parm('ropPath').set(rop.path())

	return node, rop


def errorSwitch(parent, node=None):
	null = parent.createNode('null','nothing')
	switch = parent.createNode('switch','error_switch')
	switch.setInput(0,null)
	layout = [null,switch]
	if node:
		layout.append(node)
		switch.setInput(1,node)
		out = node.inputs()
		if out:
			out[0].setInput(0,switch)
			layout.append(out[0])

	parent.layouChildren(layout)
	switch.parm('input').setExpression(
		'!strmatch("*Error:*",'
		'run("opinfo " + opinputpath(".",1))) + ($FF-$FF)'
	)


def assetVersion(node,padding=3):
	path = node.type().definition().libraryFilePath()
	regex = r'.+/houdiniAssets/(.+)/otls.+'
	match = re.match(regex,path)
	if match:
		version = [int(x) for x in match.group(1),split('.') if x.isdigit()]
		return version
	return None		

def nodeType(node):
	return node.type().nameComponents()[2]

def nodeVersion(node):
	return tuple(node.type().nameComponents()[-1].split('.'))

def getShotPath(project=None, scene=None, shot=None):
	project = project or os.getenv('JOB')
	scene = scene or os.getenv('SCENE')
	shot = shot or os.getenv('SHOTNAME')

	path = '/jobs/{project}/{scene}/{shot}'.format(
		project=project,
		scene=scene,
		shot=shot,

	)
	return path

def getHoudiniShotPath(project=None, scene=None, shot=None,user=None):
	user = user or os.getenv('USER')
	path = '%s/houdini/hip/%s' % (getShotPath(projecr, scene, shot), user)
	return path	

def addOverscan(camera):
	resx_expr = '%s * ch("winsizex")' % camera.parm('resx').eval()
	resy_expr = '%s * ch("winsizey")' % camera.parm('resy').eval()
	camera.parm('resx').setExpressions(resx_expr)
	camera.parm('resy').setExpressions(resy_expr)
	camera.parm('resolutionoverride').set(True)
	camera.parm('overscanoverride').set(False)
	camera.parm('winsizex').set(1.2)
	camera.parm('winsizey').set(1.2)
	camera.parm('winsizeoverride').set(True)
	camera.parm('winoverride').set(False)


def listNodes(node_types):
	nodes = [x for x in hou.node('/').allSubChildren()
			if x.type().name() in node_types]
	return nodes


def extractJobId(output):
	for line in output:
		result = re.match(maruja.JOBID_REGEX,line)
		if result:
			yield result.group(1)


def _launchAndReturnJobId(node,parm):
	parm = node.parm(parm)

	with mutils.Capturing() as output:
		parm.pressButton()

	return list(extractJobId(output))


def launchToFarm(node):
	if not isinstance(node,hou.Node):
		node = hou.node(node)

	_map = {
		'mpcRelease':'release',
		'mpcMultiRelease': 'release_all_inputs',
		'mp_LaunchRender': 'enFarm',
		'dh_h14_bakegeo':'enFarm',
		'dh_multisubmit':'submitAll'
	}

	ntype = node.type().name()
	parm = _map.get(ntype)
	if not parm:
		raise ValueError(
			'Could not submit node "%s": Node type "%s" not supported' (
				node.path(),ntype)
		)

	return _launchAndReturnJobId(node,parm)
