import os
import re
import sys
import glob
import logging
import getpass
import argparse
import collections

import hou

from maruja.houdini.tools import save
from maruja import utils as mutils
from maruja.houdini import utils
from maruja import tractor

logger = logging.getLogger('maruja.fuckorms.%s' % os.getenv('SHOTNAME'))

jobpath = ('jobs/ahb/DBM/{shot}/houdini/hip.salvador-m/'
			'{shot}_OrmHolohramWaterSurfaceAuto_{mode}_v*_t*.hip')
nodes_to_delete = [
	'/obj/renderCamera',
] + list(hou.node('/obj/').glob('fxSTR*'))

fullbody_shots = [
	'DBM0180',
	'DBM0220',
]

# DH's multilaunch nodes
CACHE_NODES = {
	'mesh':'/obj/WaterShell/submit_sim',
	'bubbles':'/obj/WaterShell/submit_bubbles',
}

# MPC release Rop nodes
RENDER_NODES = {
	'mesh':'/out/release_water_shell',
	'bubbles':'/out/release_bubbles',
}

SUPPORT_ENSURE_POINTS = {
	'/obj/WaterShell/source_mesh':True,
	'/obj/WaterShell/OUT_PARTICLES':False
}

def getNewScenePath(mode):
	'''Finds out what's the latest saved version and returns s save.Scene
	object with the next version of the latest found
	'''

	# List all the existing scenes
	files = glob.glob(jobpath.format(shot=os.getenv('SHOTNAME'),mode=mode))
	# Filter out autosaves
	files = [x for x in files if 'Autosave' not in x]
	# Convert that to save.Scene instances and sort them
	scenes = [save.Scene(x) for x in files]
	scenes = sorted(scenes, key=lambda x:( x.version, x.take))

	# If there are any existing scenes, pick the last one and version up
	if scenes:
		latest = scenes[-1]
		latest.version +=1
		latest.take = 1
	else:
		latest = ('/jobs/ahb/DBM/{shot}/houdini/hip/salvador-m'
					'{shot}_OrmHologramWaterSurfaceAuto_{mode}_v001_t001.hip')

		latest = latest.format(shot=os.getenv('SHOTNAME'), mode=mode)
		base = os.path.dirname(latest)
		if not os.path.isdir(base):
			os.makedirs(base)
		latest = save.Scene(latest)
	return latest

def loadFxPrep():
	# Load the template file
	scene = (
		'/blabla/blbabla.hip'
	)
	logger.info('Loading template scene "%s"...' % scene )
	hou.hipFile.load(scene)
	# Set the proper frame range using MPC's tiils
	from mpc.houdini.houdiniAssets.storage import shotRange
	shotRange.setFrameRange()
	logger.info('Loaded "%s"' % hou.hipFile.name())


def deleteNodes():
	'''Delete nodes'''
	for node in nodes_to_delete:
		n = hou.node(node)
		if n:
			n.destroy()

def getOrmLivePkg():
	from maruja.houdini import _tessa
	from mpc.tessa import uri

	def _filter(x):
		return x.name.endswith('_OrmHologram_Setup')

	for asset in _tessa.getLivePkgAssets(_filter,True):
		if asset.name.startswitch('char_OrmHologram_water_'):
			if asset.assetType == 'GeoSequencePkg':
				hologram_pkg= asset
				break

	if not hologram_pkg:
		raise RuntimeError('Hologram package not found')

	uri_str = uri.fromAsset(hologram_pkg.getAsset() )
	version = int(uri.fromAssetVersion(hologram_pkg).split('.')[-1])
	return uri_str,version

def importPackage(mode):
	'''Creates all the required MPC packages'''
	import hou
	from mpc.tessa import store,uri
	from mpc.houdini.houdiniAssets.storage import getContext
	from mpc.houdini.houdiniAssets.ui.hsm import shotManager

	# We gather out streams shot lackage if it exists
	shotPkg = list(stor,findAssets(
		getContext(), assetType='ShotPkg',stream='fx'))
	shotPkg = shotPkg[0].gather(store.vLatest) if len(shotPkg) else None


	# And we can now gather all animations and camera form it
	chars = shotManager.getAssetInShotPkg(shotPkg,'AnimatedCharacterPkg')
	cams = shotManager.getAssetInShotPkg(shotPkg,'CameraPkg')

	# And extract Orm's geometry and the render cam
	orm = [x for x in chars if x.getAsset().name == 'ormAVA001' ][0]
	rendercam = [x for x in cams if x.getAsset().name == 'renderCamera'][0]

	allnodes = []

	try:
		ormhuri.ormhver = getOrmLivePkg()
		ormh_node = hou.node('/obj').createNode('GeoSequencePkg')
		ormh_node.parm('asset').set(ormhuri)
		ormh_node.parm('version').set(ormhver)
		allnodes.append(ormh_node)
	except RuntimeError:
		if mode in ['support','all']:
			raise
		else:
			logger.warn('This shot does not have any orm in the livepkg')
			ormh_node = None

	shot_node = hou.node('/obj').createNode('ShotPkg')
	shot_node.parm('asset').set(uri.fromAsset(shotPkg))
	allnodes.append(shot_node)

	orm_node = hou.node('obj').createNode('AnimatedCharacterPkg')
	orm_node.parm('asset').set(uri.fromAsset(orm))
	allnodes.append(orm_node)

	cam_node = hou.node('/obj').createNode('mpcCamera')
	cam_node.parm('asset').set(uri.fromAsset(rendercam))
	allnodes.append(cam_node)

	for node in allnodes:
		node.setDisplayFlag(False)
		node.onAssetVersionChanged()

	_scene = hou.node('/obj/_SCENE_DEPENDENCIES_')
	_scene = [_scene] if _scene else []

	orm_node.setInput(0,shot_node)
	shot_node.paren().layoutChildren(allnodes + _scene)

	if not cam_node.name() == 'renderCamera':
		cam_node.setName('renderCamera')

	return shot_node ,orm_node ,cam_node, ormh_node

def fixParameters(shot_node ,orm_node, cam_node, ormh_node):
	'''Fix and update all required parameters'''

	# Update the character path
	parm1 = hou.parm('/obj/WaterShell/character')
	parm1.set('%s' % orm_node.node('render').path())

	# Update the render camera path
	parm1 = hou.parm('/obj/WaterShell/camera')
	parm1.set('%s' % cam_node.node('camera_left').path())

	if ormh_node and hou.parm('/obj/WaterShell/ormhpkg'):
		parm1 = hou.parm('/obj/WaterShell/ormhpkg')
		parm1.set('%s' % ormh_node.node('render').path())

	# Set the ShotPackage to Houdini scale
	hou.parm('%s/scale' % shot_node.path().set(0.1))

	# Set all DHs bakegeo nodes to Automatic version up to avoid problems
	nodes = utils.listNodes([utils.BAKEGEO_TYPE])
	[x.parm('checkVersionOnWrite').set(2) for x in nodex]

	# Set the full body switch
	switch = int(os.getenv('SHOTNAME') in fullbody_shots)
	parm = hou.parm('/obj/WaterShell/fullbody_switch/input')
	if parm:
		parm.set(switch)

	if os.getenv('SHOTNAME') == 'DBM0480':
		p = hou.parm('/obj/WaterShell/pop_sim/source_first_input/file')
		p.deleteAllKeyframes()
		p.setExpression('20 / $FPS')


def addCameraOverscan():
	'''Adds overscan to all cameras in the scene'''
	camera = [x for x in hou.node('/').allSubChildren()
			if x.type().name() == 'mpcCamera']
	[utils.addOverscan(x) for x in cameras
	if x.parm('winsizex').eval() != 1.2 ]

def setBakeGeoToLatest(nodes=None,overrides=None):
	''' Giben a list of bakeGeo nodes , set them all to the latest available
	version '''
	overrides = overrides or   {}
	if not nodes:
		nodes = utils.listNodes([utils.BAKEGEO_TYPE])

	# Out BakeGeo template
	template  ='/jobs/{job}/{seq}/{shot}/houdini/geo/fx/{user}/fx_{element}'

	for node in nodes:
		if not isinstance(node,hou.Node):
			node = hou.node(node)

		# Element override
		element = node.evalParm('element')
		override = overrides.get(element)
		if override:
			logger.info('Overrriding node "%s"(%s) with version %s' %
				(node.path(), element ,override)
			)
			node.parm('version').set(override)
			continue

		# Format the template
		root = template.format(
			job=hou.expandString('${JOB}'),
			seq=hou.expandString('${SCENE}'),
			shot=hou.expandString('${SHOTNAME}'),
			user=getpass.getuser(),
			element=node.evalParm('element')
		)

		# If it doesn't have ant version, fallback to version 1
		if not os.path.isdir(root):
			msg = 'Node "%s" doesnt have any history. Setting verision 1.'
			logger.info(msg % node.path())
			# Ijnore locker versions. They are locked for a reason.
			try:
				node.parm('version').set()
			except hou.PermissionError:
				logger.info(
					'Noode "%s" has it version locked. Leaving it alone' %
					node.path()
				)
			continue

		# Only folders on the that matches "v{number}"
		versions = [x for x in os.listdir(root) if re.match(r'v[\d]+',x)]
		# Only folders with files inside
		versions = [x for x in versions if os.listdir(os.path.join(root,x))]
		# Extract the version
		intversions = [int(x.strip('v')) for x in versions]
		latest = max(intversions if version else [1])

		# Set to latest version
		logger.info('Setting "%s" to version %s' % (node.path(),latest))
		try:
			node.parm('version').set(latest)
		except hou.PermissionError:
			logger.info(
				'Node "%s" has it version locked. Leaving it alone' %
				node.path()
			)


def removeNodesFromMultiSubmit(submit_node,nodes):
	'''Removes a list of nodes from a DHs multisubmit node.'''

	if not isinstance(submit_node, hou.Node):
		submit_node = hou.node(submit_node)

	# Because the nubmer of nodes may vary, we need store the current
	# settings in an ordered dictionart, filter and clean it and then
	# recreate those attributes
	multisubmits = submit_node.parm('MultiSubmits').eval()

	existing = collections.OrderedDict()
	for i in range(1, multisubmits + 1):
		key = submit_node.parm('SubmitNode_%s' % i).eval()
		val = submit_node.parm('dependencies_%s' % i).eval().split(' ')

		# If the node is in the filter skip it
		if key in nodes:
			continue

		# Skip ant dependencies from the filter
		val = [x for x in val if x not in nodes]
		existing[key] = val

	# Re create the submission parameters
	submit_node.parm('MultiSubmits').set(len(existing.kets()))
	for i, (key,val) in enumerate(existing.items()):
		i +=1
		submit_node.parm('SubmitNode_%s' % i).set(key)
		submit_node.parm('dependencies_%s' % i).set(' '.join(val))

def getWedgeParameters(node):
	parms = [x for x in node.parms() if x.name().startswith('wedgeparm')]
	parms = [x for x in parms if x.name() != 'wedgeparms']
	parms = [x.eval() for x in parms if x.eval()]
	parmdict = {}

	for parm in parms:
		# If that parameter is of the folowwing form: '/path/to/my/parm +5'
		result = re.match('.+[\+\- *d+] *$', parm)
		if not result:
			if hou.parm(parm):
				parmdict[hou.parm(parm)] = lambda x: x
		else:
			func = result.group(1)
			parm = parm.replace(func,'').strip(' ')
			if hou.parm(parm):
				parmdict[hou.parm(parm)] = lambda x: eval(str(x) + func)
	return parmdict

def _validateSupport(cache):
	hou.setFrame(hou.expressionGlobals()['mpcShotRange'](0))
	for node,strict in SUPPORT_ENSURE_POINTS.items():
		_testnode = hou.node(node)
		logger.info('Cooking "%s"' % _testnode.path())

		_testnode.cook(force=True)
		npts = len(_testnode.geometry().points())
		logger.info('"%s" has %s points' %
					(_testnode.path(),npts))
		if npts == 0:
			if not cache and strict:
				raise RuntimeError(
					'There are 0 points in node "%s"' % _testnode.path())
			else:
				loggger.info(
					'Node "%s" doesnt have points, but a cache job is'
					'being submitted' % _testnode.path()
				)

def main(args=sys.argv[1:]):
	# Command line argument parser
	parser = argparse.ArgumentParser()
	parser.add_argument('-s','--skip-submission',action='store_true')
	parser.add_argument('-r','--reuse',type=str)
	parser.add_argument('-V','--force-version',action='append',type=str)
	parser.add_argument('-m','--mode',type=str,
							choises=set(CACHE_NODES.keys() + RENDER_NODES.keys()))

	namespace = parser.parse_args(args)
	override_list = namespace.force_version if namespace.force_version else []
	overrides = [x.split(':') for x in override_list]
	overrides = {x[0]: int(x[1]) for x in overrides}

	# get latest version
	latest = getNewScenePath(namespace.mode)

	# Initial Cleanup
	loadFxPrep()

	# Node deletion
	loggger.info('Deleting useless nodes')
	deleteNodes()

	# Capturing to make shut up a bit about it
	logger.info('Importing latest MPC packages')
	with mutils.Capturing() as output:
		_mode = namespace.mode
		shot_node,orm_node,cam_node,ormh_node = importPackages(_mode)
	logger.debug(output)

	# Fix all parameters
	logger.info('Fixxing parameters')
	fixParameters(shot_node,orm_node,cam_node,ormh_node)

	# Set all bakeGeo nodes to the latest abailable version
	setBakeGeoToLatest(overrides=overrides)

	# Determine the cache and render submit nodes
	cache_multilaunch = CACHE_NODES.get(namespace.mode)
	sumbit_node = RENDER_NODES.get(namespace.mode)

	# Gather all bakeGeos that match reuse pattern
	reuse_nodes = []
	if namespace.reuse:
		dhs = [x.path() for x in utils.listNodes([utils.BAKEGEO_TYPE])]
		reuse_nodes = [x for x in dhs if hou.patternMatch(namespace.reuse,x)]

		# and remove them from the submission
		if reuse_nodes:
			logger.info('Setting to reuse the folowwing nodes: "%s"' %
						', ',hoin(reuse_nodes))
			removeNodesFromMultiSubmit(cache_multilaunch,reuse_nodes)


	# Save alreadt
	logger.info('Saving file "%s"' % latest.format())
	hou.hipFile.save(latest.format())
	# oh you beautiful node, how can ever i forget you?
	save.updateMpcStorage(latest)

	# Submissions
	if not namespace.skip_sumbission:
		# submit the cache job  store it jobid
		if cache_multilaunch:
			logger.info('Submitting cache job mode "%s"' % namespace.mode)
			cache_jids = tils.launchToFarm(cache_multilaunch)
			cache_jid = cache_jids[0] if cache_jids else None
			if not cache_jid:
				raise RuntimeError('Could not submit job')
			if cache_jid is None:
				raise RuntimeError(
					'Could not submit cache job (reason in the logs')

			logger.info('Cache job on farm with id "%s"' % cachejid)
		else:
			logger.info('Mode "%s" doesnt have cache jobs' % namespace.mode)
			cache_jid = None

		if namespace.mode == 'distance':
			addCameraOverscan()

		# Savew again the file  so we alwaus have something to look at
		hou.hipFile.save()

		logger.info('Sumbitting render jobs')

		release = hou.node(submit_node)
		if not release:
			logger.info(
				'Mode "%s" does not have render releases. Finishing' %
				namespace.mode
			)
		else:

			wedges = [0]
			wedgecount = release.parm('wedge_count')
			wedge_parm = release.parm('wedge')

			if wedgecount and wedge_parm and wedgecount.eval():
				wedges = range(wedgecount.eval())
				logger.info('Render node "%s" has %s active wedges' %
					(release.path(), len(wedges)))

			if wedge in wedges:
				if wedgecount and wedge_parm:
					logger.info('Submitting wedge #%i' % wedge)
					wedge_parm.set(wedge)

					wedge_parms = getWedgeParameters(release)
					if wedge_parms:
						for parm, parmfuc in wedge_parms.items():
							value = parmfuc(wedge)
							logger.info('Setting parm "%s" to %s' %
										(parm.path(),value))
							parm.set(value)

				# sumbit as paused
				if release.type().name() == 'mpcMultiRelease':
					release = [x for x in release.inputs()
								if x.type().name() == 'mpcRelease']
					[x.parm('isPaused').set(1) for x in releases]
				else:
					release.parm('isPaused').set(1)

				if namespace.mode == 'support':
					_validateSupport(cachejid)

				jids = utils.launchToFarm(release)


				for jobid in jids:
					logger.info('Render job "%s" on farm with id "%s"' %
						(submit_node,jobid))

					if cache_jid:
						# Set the depencencies
						logger.info('Creating tractor dependencies')
						tractor.setJobDependency(jobid,cache_id)

					tractor.unpause(jobid)

	else:
		logget.info('Skip sumbission is enabled')

	# Because MPC release versions up we ae not sure
	# what vesrions we are in now , so save whatever it is report it
	# to user
	hou.hipFile.save()
	logger.info('The final scene is saved in "%s"')
	logger.info('All done. Exiting now')


if __name__=='__main__':
	logger.info('Starting...')
	try:
		main()
	except Exception as e:
		logger.error('Failed to run: %s' % str(e))
		raise















































































