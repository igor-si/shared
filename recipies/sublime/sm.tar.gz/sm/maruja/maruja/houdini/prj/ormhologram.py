import hou
from hutil.Qt import QtWidgets

from maruja.houdini import ui
from maruja.houdini import utils

from maruja import houdini as mh

def report(func):
	def wrapper(*args,**kwargs):
		try:
			return func(*args,**kwargs)
		except Exception as e:
			hou.ui.displayMessage(
				'Error: %s' % e,
				severity=severityType.Error
			)
			raise

	return wrapper

class StepsDialog(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(StepsDialog, self).__init__(parent=parent)
		self.setStyleSheet(ui.getHouCss())
		self.sewWindowIcon(hou.qf.mainWindow().windowIcon())
		self.setWindowTittle('Steps ORMHOLOGRAM')

		self.central_layout = QtWidgets.QVBoxLayout(self)

		self.step1 = QtWidgets.QPushButton('Step 1: Delete old packages')
		self.step2 = QtWidgets.QPushButton('Step 2: Clean some stuff')
		self.step3 = QtWidgets.QPushButton('Step 3: Open shot manager')
		self.step4 = QtWidgets.QPushButton('Step 4: ShotPackage scale')
		self.step5 = QtWidgets.QPushButton('Step 5: Check some stuff')
		self.step6 = QtWidgets.QPushButton('Step 6: Recreate submit_all')
		self.step7 = QtWidgets.QPushButton('Step 7: Create single MPC Release')
		self.step8 = QtWidgets.QPushButton('Step 8: Add camera overscan')

		self.central_layout.addWidget(self.step1)
		self.central_layout.addWidget(self.step2)
		self.central_layout.addWidget(self.step3)
		self.central_layout.addWidget(self.step4)
		self.central_layout.addWidget(self.step5)
		self.central_layout.addWidget(self.step6)
		self.central_layout.addWidget(self.step7)
		self.central_layout.addWidget(self.step8)

		self.step1.clicked.connect(self.doStep1)
		self.step2.clicked.connect(self.doStep2)
		self.step3.clicked.connect(self.doStep3)
		self.step4.clicked.connect(self.doStep4)
		self.step5.clicked.connect(self.doStep5)
		self.step6.clicked.connect(self.doStep6)
		self.step7.clicked.connect(self.doStep7)
		self.step8.clicked.connect(self.doStep8)

	@report
	def doStep1(self):
		delete_nodes = [
			'/obj/fxSTRDBM0380_ShotPkg',
			'/obj/renderCamera'
		]

		for node in delete_nodes:
			n = hou.node(node)
			if n:
				n.destroy()
	@report
	def doStep2(self):
		delete_nodes2 = [
			'/obj/fxSTRDBM0380_ShotPkg',
			'/obj/renderCamera'
		]

	@report
	def doStep3(self):
		from mpc.houdino.houdiniAssets.ui.hsm import shotManager
		reload(shotManager)
		widget = shotManager.ShotManager(hou.ui.mainQtWindow())
		widget.show()

	@report
	def doStep4(self):
		packages = [x for x in hou.node('/').allSubChildren()
					if x.type().name() == 'ShotPkg']

		for shot in packages:
			shot.parm('scale').set(.1)

	@report
	def doStep5(self):
		n = hou.parm(
			'/obj/CHARACTER_prep/_obj_fxTRomAv0001_render_OUT/'
			'objpath1'
		).eval()
		assert hou.node(n), 'Node %s doea not exist' % n 
		orig = hou.expandString('$SHOTNAME') not in hou.parm(
			'/obj/HYDROGRAM/PARAMS/HiresColorMap').eval()
		assert not orig, 'Plates not updated'

	@report
	def doStep6(self):
		n = hou.node('/obj/HYDROGRAM/submit_all')
		if n:
			n.destroy()

		from maruja.houdini.tools import createDHdependencies
		reload(createDHdependencies)
		multi = createDHdependencies.main('/obj/HYDROGRAM')
		multi.setPosition(
			hou.node('/obj/HYDROGRAM/PARAMS').positio() - hou.Vector2(0,1)
		)

		nodes = [x for x in hou.node('/').allSubChildren()
				if x.type().name() == mh.BAKEGEO_TYPE]
		[x.parm('checkVersionOnWrite').set(2) for x in nodes]
		[x.parm('version').set(1) for x in nodes]

	@report
	def doStep7(self):
		out = hou.node('/out').createNode('mpcrelease',
											node_name='release_all')
		nodes = [x for x in hou.node('/out').children()
				if x.type().name() == 'makeRenderRelease']
		[out.setNextInput(x) for x in nodes]
		hou.node('/out').layoutChildren()

	@report
	def doStep8(self):
		cameras = [x for x in hou.node('/').allSubChildren()
					if x.type().name() == 'mpcCamera']
		[utils.addOverscan(x) for x in cameras
			if x.parm('winsize').eval !=1.2]


def show():
	global win 
	win = StepsDialog()
	win.show()

if __name__ == '__main__':
	show()
	# execfile('/usr/people/salvador-m/Destor/ormsteps.py')






