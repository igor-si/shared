import nuke
import getpass

_passes = [
	"Blabla__blabla_010",
	"Balabla__blabla_010",
]

reads = nuke.allNodes('Read')
if not reads:
	raise ValueError('One HubRead is required')

read = reads[0]
enum = read.knobs().get('user_filter')

if getpass.getuser() in enum.values():
	enum.setValue(getpass.getuser())

layers = read.knobs().get('layer').values()
layers = [x for x in layers if any([y in x for y in _passes])]
nuke.nodeCopy('%clipboard%')
for i in range(len(layers) -1 ):
	nuke.nodePaste('%clipboard')

texts = []

for i,node in enumerate(nuke.allNodes('Read')):
	s = nuke.allNodes()
	for si in s:
		si['selected'].setValue(False)
	try:
		node.knobs().get('layer').setValue(layers[i])
		node.setName(layers[i])
		node['selected'].setValue(True)
		txt = nuke.createNode('Text')
		node.setInput(0,txt)
		txt['box'].setValue((0,0,2597,1670))
		txt['yjustify'].setValue('top')
		txt['message'].setValue(layers[i])
		texts.append(txt)
	except Exception as e:
		print e

cs = nuke.createNode('ContactSheet')
for i, text in enumerate(texts):
	cs.setInput(i, text)