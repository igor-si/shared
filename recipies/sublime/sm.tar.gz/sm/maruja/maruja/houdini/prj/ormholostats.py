import os
import re
import datetime
import sys
import csv
import argparse
import getpass

shots = [
	'0180',
	'0190',
]

elements = [
	'OrmProxy',
	'OrmEmissionVolume',
]

def writeCsv(data,output):
	with open(output, 'wb') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ')
		spamwriter.writerow([''] + elements)
		for shot in shots:
			row = ['DBM%s' % shot]
			for element in elements:
				row.append(data[shot][element])
			spamwriter.writerow(row)

def getStatus(shot,element):
	template = '/jobs/ahb/DBM/DBM{shot}/houdini/geo/fx/{user}/fx_{element}/'
	root = template.format(shot=shot, user = getpass.getuser(), element=element)
	if not os.path.isdir(root):
		return

	versions = [x for x in os.listdir(root) if re.match(r'v[\d]+',x)]
	# Only folders with files inside
	versions = [x for x in versions if os.listdir(os.path.join(root,x))]
	# Extract the version
	intversions = [int(x.strip('v')) for x in versions]
	latest = max(intversions)
	latest = versions[intversions.index(latest)]

	timesinceepoch = os.stat(os.path.join(root,latest)).st_ctime
	date = datetime.datetime.fromtimestamp(timesinceepoch)
	date = date.strftime('%d/%B')
	return '%s (%s)' % (latest, date)

def run(args=sys.argv[1:]):
	parser = argparse.ArgumentParser()
	parser.add_argument('file')
	namespace = parser.parse_args(args)

	data = {}
	for shot in shots:
		data[shot] = {}
		for element in elements:
			status = str(getStatus(shot,element))
			data[shot][element] = status

	writeCsv(data, namespace.file)


if __name__=="__main__":
	run()