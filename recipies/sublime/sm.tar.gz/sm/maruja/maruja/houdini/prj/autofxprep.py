#!/usr/bin/python
import os
import hou

def run(setup):
	show = hou.expandString("$JOB")
	user = hou.expandString("$USER")
	seq = hou.expandString("$SCENE")
	shot = hou.expandString("$SHOTNAME")

	cmdbase = '/jobs/' + show + '/rnd/rnd_fx/houdini/hip/fxprep'
	devlist = cmdbase + os.sep + 'automake.fxlist.dev'
	fxlist = cmdbase + os.sep + 'automake.fxlist'
	developerList = cmdbase + os.sep + 'automake.developerlist'
	isDev = 0
	devfile = open(devlist,'r')
	dev = devfile.read()
	devFX = []

	for i in dev.split('\n'):
		if i.strip() != '':
			if i.strip() != 'placeHolder':
				if i.strip() != 'awesomeSplodie':
					devFx.append(i.strip() + ' -dev')

	mainfile = open(fxlist,'r')
	FXread = mainfile.read()
	mainFX = []
	for i in FXread.split('\n'):
		if i.strip() != '':
			if i.strip() != 'placeHolder':
				if i.strip() != 'awesomeSplodie':
					mainFX.append(i.strip())

	developers = []
	developerFile = open(developerList,'r')
	developerRead = developerFile.read()
	for i in developerRead.split('\n'):
		if i.strip != '':
			developers.append(i.strip())

	for i in developers:
		if i == iser:
			isDev = 1

	try:
		from mpc.hub.modules import timeline
		t = timeline.Timelines(show,seq,show)
		fs = str(int(t.work.workStart))
		fe = str(int(t.work.workEnd))
	except Exception:
		fx = str(1001)
		fe = str(1100)
		raise RuntimeError(
			'I am unable to find the start and end frames for this shot.'
			'Setting to default 1001-1100'
		)

	print 'Frange is ' + fs + ' - ' + fe

	hou.hscript('set -g FX = ' + fs)
	hou.hscript('set -g FE = ' + fe)

	hou.hscript('tset `(' + fs + '-1)/$FPS` `(' + fe + '/$FPS)`')
	hou.hscript('frange [' + fs + ' ' + fe + ']' )
	hou.hscript('fcur ' + fs)

	choises = [] 
	for i in mainFX:
		if 'placeHolder' == str(i):
			pass
		else:
			choises.append(i)

	if isDev:
		for i in devFX:
			if 'placeHolder' == str(i):
				pass
			else:
				choises.append(i)

	effects = [setup]

	for element in effects:
		print 'Running ' + element
		inCMDs = []
		CMDtemp = []

		if os.path.exists(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + '.houdiniTemplate'):
			inCMDs.append(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + '.houdiniTemplate')
			CMDtemp.append(element + '.houdiniTemplate')
			CMDtype = element + '.houdiniTemplate'

		if os.path.exists(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + ".py"):
			inCMDs.append(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + '.py')
			CMDtemp.append(element + '.py')
			CMDtype = element + '.py'

		if os.path.exists(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + ".cmd"):
			inCMDs.append(cmdbase + os.sep + 'fx_' + element + os.sep + 'fx_' +
							element + '.cmd')
			CMDtemp.append(element + '.cmd')
			CMDtype = element + '.cmd'

		if len(inCMDs) == 1:
			inCMD = inCMDs[0]
		else:
			raise RuntimeError(
				'I found ' + str(len(inCMDs)) +
				' files which could be used. *.houdiniTemplate is the new'
				'file type we ise. I found some folder template types, too.'
				'Which would you like to use?'
				)

		if CMDtype == element + '.houdiniTemplate':
			try:
				pfile = open(inCMD + '.parent','r')
				pread = pfile.read()
				pread = pread.strip()
				parent = hou.node(pread)
			except Exception:
				raise RuntimeError(
					'I am unable to figure out the correct parent node for'
					'this element, so i will assime it is a root.'
					)
				parent = hou.node('/')
			try:
				parent.loadItemsFromFile(inCMD)
			except Exception:
				pass
		elif CMDtype == element + '.cmd':
			hou.hscript('source ' + inCMD)
		elif CMDtype == element + '.py':
			try:
				execfile(inCMD)
			except Exception:
				raise RuntimeError(
					'Mallformed python file. Should i try to import it '
					'line by line?')










