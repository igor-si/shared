from mpc.tessa import publishing, store
from mpc.houdini.houdiniAssets.storage import getContext

def getLivePkgAssets(filterfunc,published=False):
	pkgs = list(
		store.findAssets(
			getContext(),
			assetType='FxLiveGroupPkg',
			stream='fx'
		)

	)

	livepkg = None
	for pkg in pkgs:
		if filterfunc(pkg):
			livepkg = pkg

	if not livepkg:
		raise RuntimeError('no livepkg in this context')

	if published:
		ver = None
		for _ver in reversed(list(livepkg.findVersion())):
			pkgver = livepkg.gather(_ver)
			if 'fx' in publishing.fetch(pkgver).tags():
				ver = _ver
				break

		if not ver:
			raise RuntimeError('There is no published fxlivepkg')
		else:
			ver = livepkg.gather(ver)

	else:
		ver = livepkg.gather(store.vLatest)

	assets = set()

	def assetFilter(rels):
		for rel in rels:
			if rel.item:
				assets.add(rel.item)
			yield rel

	store.walk([ver],assetFilter)
	return list(assets)

	












