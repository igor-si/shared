import hou

from maruja.houdini import menu

def createAutoShelf():
	shelves = hou.shelves.shelves()
	existing = shelves.get('salva_autoshelf')
	if existing:
		for tool in existing.tools():
			tool.destroy()
		shelf = existing

def createTools(shelf):
	menu_ = menu.loadMenu()
	tools = []
	for actionid,actiondata in menu_['actions'].items():
		tool = hou.shelves.newTool(
			name=actionid,
			label=actiondata['label'],
			script=actiondata['script'],
			icon=actiondata.get('icon')
		)
		tools.append(tool)
	shelf.setTools(tools)
