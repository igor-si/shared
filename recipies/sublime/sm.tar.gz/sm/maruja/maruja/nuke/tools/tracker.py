import json
import nuke
import os

from maruja import config

def trackRelease(node=None):
	versions = gatherVersions(node)

	target = _trackerConfigPath()

	daily = nuke.getInput('Daily version','')

	if not daily or not daily.isdigit():
		return

	data = {
		'versions':versions,
		'daily': int(daily)
	}
	with file(target, 'r') as f:
		sdata = json.load(f)

	sdata.append(data)

	with file(target , 'w') as f:
		json.dump(sdata, f, indent=4)

def _trackerConfigPath():
	target = os.path.join(
		config.tracker_path,
		os.getenv('JOB'),
		os.getenv('SCENE'),
		os.getenv('SHOTNAME'),
		)
	if not os.path.isdir(target):
		os.makedirs(target)

	target = os.path.join(target,'nuketracker.json')
	if not os.path.isfile(target):
		with file(target, 'w') as f:
			f.write('[]')
	return target

def gatherVerions(node=None):
	node = node or nuke.selectedNode()

	reads = creepNodes(node,['Read','DeepRead'])
	versions = {}

	for read in reads:

		layerknob = read.knob().get('layer')
		versionknob = read.knob().get('layerVersion')

		if not layerknob or not versionknob:
			continue

		layer = layerknob.value()
		if layer.startswith('FX_'):
			layer = layer[3:]
		versions[layer] = int(versionknob.value())

	return versions

def _creepNodes(node,node_types):
	nodes = []
	if not node:
		return nodes

	for input_ in range(node.inputs()):
		nodes += _creepNodes(node.input(input_),node_types)

	if node.Class() in node_types:
		nodes.append(node)

	return nodes

























