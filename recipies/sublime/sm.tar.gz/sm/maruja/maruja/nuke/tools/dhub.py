from PySide import QtGui
import nuke
import json

def sceneReads():
	reads = nuke.allNodes('Read')
	reads = dict([(x.name(),x) for x in reads])
	return reads

def sceneDeepReads():
	reads = nuke.allNodes('DeepRead')
	reads = dict([(x.name(),x) for x in reads])
	return reads

def pasteReads():
	app = QtGui.QApplication.instance()
	clipboard = app.clipboard()
	data = json.loads(clipboard.text())

	scene_reads = sceneReads()
	scene_dreads = sceneDeepReads()
	for node,readpaths in data.items():
		read = scene_reads.get(str(node))

		parms = dict(
			name=node,
			file=readpaths['mono'],
			first=int(readpaths['range'][0]),
			last=int(readpaths['range'][1])
		)
		if not read:
			nuke.nodes.Read(raw=True,**parms)
		else:
			for key,val in parms.items():
				read.knob(key).setValue(val)

		if not readpaths['deep']:
			continue

		dname = node + "_deep"
		read = scene_dreads.get(str(dname))

		parms = dict(
			name=dname,
			file=readpaths['deep'],
			first=int(readpaths['range'][0]),
			last=int(readpaths['range'][1])	
		)
		if not read:
			nuke.nodes.DeepRead(**parms)
		else:
			for key,val in parms.items():
				read.knob(key).setValue(val)





