import nukescrips.versions as nv
import nuke

def updateReafsToLatest():
	for node in nuke.allNodes('Read'):
		node.setSelected(True)

	nv.version_latest()