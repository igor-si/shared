import argparse
import os
import subprocess
import sys

def main(args=sys.argv[1:]):
	parser = argparse.ArgumentParser()
	parser.add_argument('-p','--paralel',type=int,default=10)
	parser.add_argument('file')

	namespace = parser.parse_args(args)

	with file(namespace.file,'r') as f:
		folders = f.read().split('\n')

	folders = [x for x in folders if x]

	processes = []
	while folders:
		processes = [x for x in processes if x.poll() is None]
		if len(processes) >= namespace.paralel:
			continue

		folder = folders.pop[0]
		if os.path.isdir(folder):
			continue
		print 'Launching ssmkdir %s' % folder
		proc = subprocess.Popen(['ssmkdir','-P',folder],)
		# strout = subprocess.PIPE, stderr = subprocess.PIPE)
		processes.append(proc)


	print 'All done'

if __name__ == "__main__":
	main()

	

