import os
import logging

__version__ = '0.1.0'

# Logging
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)

formatter = logging.Formatter('[%(levelname)-7s][%(name)-20s] %(message)s')
handler.setFormatter(formatter)

logger = logging.getLogger('maruja')
logger.handlers = [handler]
logger.setLevel(os.getenv('MARUJA_LOG_LEVEL',logging.INFO))

logger.debug('Maruja logger set up')


# Variables
try:
	import hou
	AnyException = (Exception,hou.Error)
except:
	AnyException = (Exception)

JOBID_REGEX = r'.*Ok job script accepted, jid: (\d+).*'