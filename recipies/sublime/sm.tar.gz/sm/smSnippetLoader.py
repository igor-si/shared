import os
import json
  
import hou
from hutil.Qt import QtWidgets,QtGui
#import hdefeveral

import re

"""
import sys
import os
sys.path.append('/studio/Dropbox/tools/hou/env/houdini16.0/snippets')
import smSnippetLoader
reload (smSnippetLoader)
smSnippetLoader.showPicker()
"""



def _ensureDeferredCallback():
	callbacks = hou.ui.eventLoopCallbacks()
	hasdeferred = any([x is hdefereval._processDeferred for x in callbacks])
	if not hasdeffered:
		hdefereval._is_running = False
		hdefereval._addEventLoopCallback()

def executeDeferred(callback):
	_ensureDeferredCallback()
	hdefereval.executeDeferred(callback)

def getHouCss():
	css = hou.ui.qtStyleSheet()
	regex = r'(\.*QWidget[\[\]\w\=\"\:]*)'

	def addScroll(result):
		line = result.groups()[0]
		return '%s,%s,%s'%(
			line,
			line.replace('QWidget',"QScrollArea"),
			line.replace('QWidget','QDialog')
		)
	new = []
	for line in css.split('\n'):
		result = re.sub(regex,addScroll,line)
		new.append(result)

	return '\n'.join(new)

_this = os.path.dirname(os.path.abspath(__file__))
vex_folder = os.path.join(_this,'vex')
vex_index = os.path.join(vex_folder,'_index.json')


def loadVexIndex():
	with file(vex_index,'r') as f:
		return json.load(f)

def loadSnippet(snippet,node=None,vars=None):
	if not node:
		if not hou.selectedNodes():
			nodes = hou.ui.selectedNodes()
		else:
			nodes = [x for x in hou.selectedNodes()
					if 'wrangle' in x.type().name().lower()]

		nodes = [x for x in nodes if x.parm('snippet')]

		if not nodes:
			raise RuntimeError("No se;ected node has parameters 'snipper'")
		node = nodes[0]

	_snippet = loadVexIndex()['snippets'].get(snippet)

	if not _snippet:
		raise ValueError('Snippet "%s" not found in index' % snippet)

	vars = {}
	if not vars and _snippet.get('variables'):
		vars = hou.ui.readMultiInput(
			'Snippet variables',_snippet['variables'])
		vars = vars[1]
		vars = {x:y for x in _snippet['variables'] for y in vars}

	with open(os.path.join(vex_folder,_snippet['file'])) as f:
		code = f.read()

	for key,val in vars.items():
		code = code.replace('<!%s!' % key,val)

	node.parm('snippet').set(code)

class SnipperPicker(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(SnipperPicker,self).__init__(parent=parent)
		self.setStyleSheet(self.getStyle())
		self.setWindowIcon(hou.qt.mainWindow().windowIcon())
		self.setWindowTitle('snipper picker')

		self._executed = False

		# central layout
		self.central_layout = QtWidgets.QVBoxLayout(self)

		# widgets
		self.snippet_list = QtWidgets.QListWidget()

		# assignments
		self.central_layout.addWidget(self.snippet_list)

		# initialization
		self.populateList()

		# signals
		QtWidgets.QApplication.instance().focusChanged.connect(
			self.onFocusChanged
			)
		QtGui.QShortcut(QtGui.QKeySequence("Esc"),self,self.close)
		QtGui.Qshortcut(QtGui.QKeySequence("Return"),self,self.onSubmit)

	def onSubmit(self):
		snippets = loadVexIndex()
		text = self.snippet_list.selectedItems()[0].text()
		snippet = [x for x in snippets['snippets']
					if snippets['snippets'][x]['label'] == text]
		loadSnippet(snippet[0])
		self.close

	def populateList(self):
		snippets = loadVexIndex()
		labels = [x['label'] for x in snippets['snippets'].values()]
		self.snippet_list.addItems(sorted(labels))

	def getStyle(self):
		style = getHouCss()
		style += '''
		QListWidger {
			border-radius:1;
		}
		'''

	def onFocusChanged(self,old,new):
		if new is not self.snippet_list:
			self.close()


def showPicker():
	global picker
	picker = SnipperPicker()
	picker.show()









































































