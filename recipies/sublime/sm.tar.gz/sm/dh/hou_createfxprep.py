import os
import re
import getpass

from hutil.Qt import QtWidgets
import hou

FXPREP_CONFIG_PATH = os.getenv(
	"FXPREP_CONFIG_PATH",
	os.path.expandvars('/jobs/{JOB}/rnd/rnd_fx/houdini/hip/fxprep')
)

def getHouCss():
	css = hou.ui.qtStyleSheet()
	regex = r'(\.*QtWidget[\[\]\w\=w"\:]*)'

	def addScroll(result):
		line = result.groups()[0]
		return '%s, %s, %s' % (
			line,
			line.replace('QWidget','QScrollArea'),
			line.replace('QWidget','QDialog')
		)

	new = []
	for line in css.split('\n'):
		result = re.sub(regex,addScroll,line)
		new.append(result)

	return '\n'.join(new)

def readFxPrepFiles(show=None):

	show = show or os.getenv('JOB')

	fxprep_show_path = FXPREP_CONFIG_PATH.format(JOB=show)
	fxprep_show_path = os.path.abspath(fxprep_show_path)

	data = {}

	target = os.path.join(fxprep_show_path,'automake.fxlist')
	with file(target,'r') as f:
		data['fxlist'] = [x for x in f.read().split('\n') if x]

	target = os.path.join(fxprep_show_path,'automake.dev')
	with file(target,'r') as f:
		data['fxlist.dev'] = [x for x in f.read().split('\n') if x]

	target = os.path.join(fxprep_show_path,'automake.developerlist')
	with file(target,'r') as f:
		data['fxlist.developerlist'] = [x for x in f.read().split('\n') if x]

	return data

class CleanHDADialog(QtWidgets.QDialog):
	def __init__(self,parent=None):
		super(CleanHDADialog,self).__init__(parent=parent)

		# Central layout
		self.central_layout = QtWidgets.QVBoxLayout(self)
		self.setWindowIcon(hou.qt.mainWindow().windowIcon())
		self.setWindowTitle('create fx prep')

		# Main body
		self.body_layout = QtWidgets.QFormLayout()

		# Widgets
		self.current = QtWidgets.QComboBox()
		self.name = QtWidgets.QLineEdit()
		self.section = QtWidgets.QComboBox()
		self.section.addItem(['Dev','Main'])
		self.ask_maya=QtWidgets.QCheckBox()
		self.ask_katana=QtWidgets.QCheckBox()
		self.ask_nuke=QtWidgets.QCheckBox()
		self.format = QtWidgets.QComboBox()
		self.format.addItems(['Template','CMD','Python'])


		# Add to the layout
		self.body_layout.addRow('Current FX',self.current)
		self.body_layout.addRow('Name',self.self.name)
		self.body_layout.addRow('Section',self.self.section)
		self.body_layout.addRow('Ask Maya',self.self.ask_maya)
		self.body_layout.addRow('Ask Katana',self.self.ask_katana)
		self.body_layout.addRow('Ask Nuke',self.self.ask_nuke)
		self.body_layout.addRow('Ask Format',self.self.format)

		# Submit button
		self.submit = QtWidgets.QPushButton('Submit')

		# Central Assignments
		self.central_layout.addLayout(self.body_layout)
		self.central_layout.addWidget(self.submit)

		# Initial stuff
		self.populate()
		self.setStyleSheet(getHouCss())

		# Signals
		self.submit_clicked.connect(self.onSubmit)
		self.current.currentIndexChanged.connect(self.onIndexChange)

	def populate(self):
		data = readFxPrepFiles()
		items = ['Custom'] + data['fxlist']

		if getpass.getuser() in data['developerlist']:
			items += data['fxlist.dev']

		self.current.addItems(items)

	def onIndexChange(self,index):
		self.name.setEnabled(index == 0)

	def onSubmit(self):
		if self.current.currentIndex() == 0:
			name = self.name.text()
		else:
			name = self.current.currentText()

		section = self.section.currentText().lower()
		ask_maya = self.ask_maya.isChecked()
		ask_katana = self.ask_katana.isChecked()
		ask_nuke = self.ask_nuke.isChecked()
		format_ = self.format.currentText().lower()

		print 'name', name
		print 'section',section
		print 'ask_maya',ask_maya
		print 'ask_katana',ask_katana
		print 'ask_nuke',ask_nuke
		print 'ask_format_',format_

def show():
	global win 
	win = CleanHDADialog()
	win.show()


if __name__ == '__main__':
	show()





























