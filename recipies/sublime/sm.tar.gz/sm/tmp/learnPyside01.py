from hutil.Qt import QtWidgets

class SampleWindow(QtWidgets.QMainWindow):
	def __init__(self,parent=None):
		super(SampleWindow,self).__init__(parent=parent)

		# currenty the window does not have anything, wee need to assign
		# an empty widged that will contain everything. This line ONLY
		# creates the widget, but does not assign it.
		self.central_widget = QtWidgets.QWidget()
		# We now create a layout for that widget
		self.central_layout = QtWidgets.QVBoxLayout(self.central_widget)

		# And now we assiign the widget to the window
		self.setCentralWidget(self.central_widget)

		# Create a button and add it to the central widget's layout
		self.go_button = QtWidgets.QPushButton('Click_me')
		self.central_layout.addWidget(self.go_button)

		# Connect the button to a signal
		self.go_button.clicked.connect(self.onButtonPressed)

		# Create a toggle and add it to the central widget's layout
		self.do_toggle = QtWidgets.QCheckBox('Do')
		self.central_layout.addWidget(self.do_toggle)

		# Connect the toggle to a signal
		
		# self.do_toggle.toggled.connect(self.onDoToggled) #doesnt work

	def onButtonPressed(self):
		print "Ypu have pressed the button"


	def onToggled(self,status):
		print 'Do toggle is now %s' % status


def run():
	global window
	window = SampleWindow()
	window.show()
