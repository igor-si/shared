#--------------------------------------------
# Creating command-line arguments for a python script
#--------------------------------------------
'''Whenever you call a python file, all the arguments are stored in "sys.argv"
like so. You can try to call this file with any arguments you want and see
what this prints
'''

import sys
print 'This file was called as', sys.argv


'''You can see that the first argument is this file, so normally we will be
using "sys.argv[1:] to skip that"
'''

'''To parse this arguments in e sensible way we can use Python "argparse"
module like so:'''
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('-m','--my-arg')

'''After we have our parser set-up, we can parse the actual eguments'''
namespace = parser.parse_args(sys.argv[1:])
print 'Namespace:',namespace

'''
More advanced exampled can be found here:
docs.python.org/2/howto/argparse.html#introducing-optional-arguments
'''

#--------------------------------------------
# Executing a file with arguments
#--------------------------------------------

'''We can execute a file using "execfile("my_file.py")", but we cannot pass
any arguments to that file, but we can do is to overrige that file's global
variables and then retrieve then using Pythons "globals()" function

Consider the folowwing example:
'''

MY_GLOBAL_VARIABLE = 'Hello'
print globals()['MY_GLOBAL_VARIABLE']

'''we can then inject into a file a namespace and use it within. For example:
'''

# We just nee to create a dummy python file
import os
# Expands '~' to your user folder
dummy_python = os.path.expanduser('~/Desktop/dummy.py')
code = 'print "This is within the file:", globals()["namespace"]'
with open(dummy_python, 'w') as f:
	f.write(code)

'''Now we need to executr that file passing out "namespace" variable
we defined earlier to this file'''

execfile(dummy_python, {'namespace':namespace})