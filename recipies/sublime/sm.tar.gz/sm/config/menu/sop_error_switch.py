import hou
from maruja.houdini import utils

reload (utils)

if hou.selectedNodes():
	target = hou.selectedNodes()[0]
	utils.errowSwitcdh(target.parent(),target)