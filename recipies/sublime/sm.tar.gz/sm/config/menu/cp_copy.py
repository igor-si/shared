from PySide import QtGui
import hou
import json

kwargs = globals().get('kwargs', {})

app = QtGui.QApplication.instance()
clipboard = app.clipboard()
string = json.dumps([x.asCode() for x in hou.selectedNodes()])
if kwargs['ctrlclick']:
	string = '\n========='.join(
		[x.asCode for x in hou.selectedNodes()])
clipboard.setText(string)
