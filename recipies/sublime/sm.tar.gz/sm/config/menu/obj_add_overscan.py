import hou
from maruja.houdini import utils

for node in hou.selectedNodes():
	if 'mpcCamera' in node.type().name():
		utils.addOverscan()