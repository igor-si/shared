from PySide import QtGui
import json
app = QtGui.QApplication.instance()
clipboard = app.clipboard()
items = json.loads(clipboard.text())
for item in items:
	exec item