from maruja.houdini.tools import dhub
import hou
reload (dhub)

sel = hou.selectedNodes()
sel = [x for x in sel if x.type().name() == 'mpc_LaunchRender']
if not sel:
	raise ValueError('No launch render node selected')
dhub.copyRenderPaths(sel[0])