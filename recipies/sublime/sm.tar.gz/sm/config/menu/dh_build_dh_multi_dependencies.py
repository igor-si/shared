from maruja.houdini import dependency as dependency
from maruja.houdini import utils
import hou
reload(dp)

exclude = None
kwargs = globals().get('kwargs',{})
if kwargs.get('ctrlclick'):
	exclude = hou.ui.readInput('Exclude')[1]

for node in hou.selectedNodes():
	if utils.nodeType(node) == 'dh_multisubmit':
		dp.fillDhBakeGeo(node,node,exclude=exclude)
		