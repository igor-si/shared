import hou
if len(hou.selectedNodes()) != 2:
	raise ValueError ('Select 2 nodes source/target')

source, target = hou.selectedNodes()
for parm in source.parms():
	targetparm = target.parm(parm.name())

	if not targetparm:
		continue

	if isinstance(targetparm.parmTemplate(),hou.StringParmTemplate):
		targetparm.revertToDefauls()
	targetparm.deleteAllKeyframes()

	if parm.keyframes():
		targetparm.setKeyframes(parm.keyframes())
	else:
		try:
			targetparm.set(parm.unexpandedString())
		except (Exception, hou.Error):
			targetparm.set(parm.eval())

			

