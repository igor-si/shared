from PySide import QtGui
import hou

app = QtGui.QApplication.instance()
clipboard = app.clipboard()
clipboard.setText(hou.expandString('$HIPFILE'))

