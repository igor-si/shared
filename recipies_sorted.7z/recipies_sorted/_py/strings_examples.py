#Here we use Pyhon string formatting to replace { } with value from variable:

print 'The fruits are {0}, {2}, {1}!'.format('Apple', 'Banana', 'Kiwi')
>>>> The fruits are Apple, Kiwi, Banana!

